<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GameController extends Controller
{
    private array $levels = [
        'easy' => 'Лёгкий',
        'medium' => 'Средний',
        'hard' => 'Сложный',
    ];

    public function index()
    {
        $games = [
            [
                'key' => 'translation',
                'title' => 'Найди перевод',
                'icon' => '⏱️',
                'description' => 'Выбирай правильный перевод слова на время.',
                'route' => 'games.translation',
            ],
            [
                'key' => 'picture',
                'title' => 'Угадай по картинке',
                'icon' => '🖼️',
                'description' => 'Смотри на картинку и выбирай английское слово.',
                'route' => 'games.picture',
            ],
            [
                'key' => 'memory',
                'title' => 'Memory Game',
                'icon' => '🧠',
                'description' => 'Найди пары: английское слово и перевод.',
                'route' => 'games.memory',
            ],
            [
                'key' => 'sentence',
                'title' => 'Собери предложение',
                'icon' => '🧩',
                'description' => 'Расставь слова в правильном порядке.',
                'route' => 'games.sentence',
            ],
            [
                'key' => 'typing',
                'title' => 'Быстрый ввод',
                'icon' => '⌨️',
                'description' => 'Введи английское слово по русскому переводу.',
                'route' => 'games.typing',
            ],
        ];

        return view('games.index', [
            'games' => $games,
            'levels' => $this->levels,
        ]);
    }

    public function translation(string $level = 'easy')
    {
        $this->checkLevel($level);

        $data = [
            'easy' => [
                ['word' => 'cat', 'correct' => 'кот', 'options' => ['кот', 'собака', 'яблоко', 'книга']],
                ['word' => 'dog', 'correct' => 'собака', 'options' => ['дом', 'собака', 'ручка', 'вода']],
                ['word' => 'book', 'correct' => 'книга', 'options' => ['молоко', 'книга', 'стол', 'школа']],
                ['word' => 'apple', 'correct' => 'яблоко', 'options' => ['банан', 'яблоко', 'сыр', 'рыба']],
            ],
            'medium' => [
                ['word' => 'teacher', 'correct' => 'учитель', 'options' => ['учитель', 'ученик', 'доктор', 'друг']],
                ['word' => 'family', 'correct' => 'семья', 'options' => ['город', 'семья', 'школа', 'еда']],
                ['word' => 'window', 'correct' => 'окно', 'options' => ['дверь', 'стена', 'окно', 'комната']],
                ['word' => 'breakfast', 'correct' => 'завтрак', 'options' => ['ужин', 'завтрак', 'обед', 'напиток']],
            ],
            'hard' => [
                ['word' => 'knowledge', 'correct' => 'знание', 'options' => ['знание', 'погода', 'движение', 'ошибка']],
                ['word' => 'environment', 'correct' => 'окружающая среда', 'options' => ['образование', 'окружающая среда', 'путешествие', 'настроение']],
                ['word' => 'responsibility', 'correct' => 'ответственность', 'options' => ['ответственность', 'возможность', 'безопасность', 'скорость']],
                ['word' => 'achievement', 'correct' => 'достижение', 'options' => ['улучшение', 'достижение', 'задание', 'развитие']],
            ],
        ];

        return view('games.translation', [
            'words' => $data[$level],
            'level' => $level,
            'levelName' => $this->levels[$level],
            'time' => $this->timeForLevel($level),
        ]);
    }

    public function picture(string $level = 'easy')
    {
        $this->checkLevel($level);

        $data = [
            'easy' => [
                ['emoji' => '🐱', 'correct' => 'cat', 'options' => ['cat', 'dog', 'bird', 'fish']],
                ['emoji' => '🐶', 'correct' => 'dog', 'options' => ['book', 'dog', 'apple', 'pen']],
                ['emoji' => '🍎', 'correct' => 'apple', 'options' => ['water', 'bread', 'apple', 'milk']],
                ['emoji' => '📚', 'correct' => 'book', 'options' => ['book', 'teacher', 'school', 'table']],
            ],
            'medium' => [
                ['emoji' => '👨‍🏫', 'correct' => 'teacher', 'options' => ['student', 'teacher', 'doctor', 'driver']],
                ['emoji' => '🏫', 'correct' => 'school', 'options' => ['house', 'school', 'shop', 'park']],
                ['emoji' => '🪟', 'correct' => 'window', 'options' => ['door', 'window', 'wall', 'floor']],
                ['emoji' => '🍳', 'correct' => 'breakfast', 'options' => ['breakfast', 'dinner', 'lunch', 'water']],
            ],
            'hard' => [
                ['emoji' => '🌍', 'correct' => 'environment', 'options' => ['education', 'environment', 'language', 'weather']],
                ['emoji' => '🏆', 'correct' => 'achievement', 'options' => ['mistake', 'achievement', 'homework', 'question']],
                ['emoji' => '🧠', 'correct' => 'knowledge', 'options' => ['knowledge', 'money', 'street', 'music']],
                ['emoji' => '🛡️', 'correct' => 'responsibility', 'options' => ['speed', 'responsibility', 'game', 'friendship']],
            ],
        ];

        return view('games.picture', [
            'items' => $data[$level],
            'level' => $level,
            'levelName' => $this->levels[$level],
        ]);
    }

public function memory(string $level = 'easy')
{
    $this->checkLevel($level);

   $allPairs = [
    ['word' => 'cat', 'image' => 'cat.svg'],
    ['word' => 'dog', 'image' => 'dog.svg'],
    ['word' => 'apple', 'image' => 'apple.svg'],
    ['word' => 'book', 'image' => 'book.svg'],
    ['word' => 'car', 'image' => 'car.svg'],
    ['word' => 'house', 'image' => 'house.svg'],
    ['word' => 'sun', 'image' => 'sun.svg'],
    ['word' => 'tree', 'image' => 'tree.svg'],
];

    // количество пар по уровню
    $count = match ($level) {
        'easy' => 4,
        'medium' => 6,
        'hard' => 8,
        default => 4,
    };

    $pairs = array_slice($allPairs, 0, $count);

    $cards = [];

    foreach ($pairs as $pair) {
        // слово
        $cards[] = [
            'type' => 'word',
            'value' => $pair['word'],
            'pair' => $pair['word']
        ];

        // картинка
        $cards[] = [
            'type' => 'image',
            'value' => $pair['image'],
            'pair' => $pair['word']
        ];
    }

    shuffle($cards);

    return view('games.memory', [
        'cards' => $cards,
        'level' => $level,
        'levelName' => $this->levels[$level], // 🔥 важно!
    ]);
}

    public function sentence(string $level = 'easy')
    {
        $this->checkLevel($level);

        $data = [
            'easy' => [
                ['ru' => 'Я люблю английский.', 'answer' => 'I like English', 'words' => ['I', 'like', 'English']],
                ['ru' => 'Это моя книга.', 'answer' => 'This is my book', 'words' => ['This', 'is', 'my', 'book']],
                ['ru' => 'У меня есть кот.', 'answer' => 'I have a cat', 'words' => ['I', 'have', 'a', 'cat']],
            ],
            'medium' => [
                ['ru' => 'Она читает книгу.', 'answer' => 'She reads a book', 'words' => ['She', 'reads', 'a', 'book']],
                ['ru' => 'Мы ходим в школу.', 'answer' => 'We go to school', 'words' => ['We', 'go', 'to', 'school']],
                ['ru' => 'Они играют вместе.', 'answer' => 'They play together', 'words' => ['They', 'play', 'together']],
            ],
            'hard' => [
                ['ru' => 'Изучение английского помогает мне развиваться.', 'answer' => 'Learning English helps me develop', 'words' => ['Learning', 'English', 'helps', 'me', 'develop']],
                ['ru' => 'Ответственность важна для успеха.', 'answer' => 'Responsibility is important for success', 'words' => ['Responsibility', 'is', 'important', 'for', 'success']],
                ['ru' => 'Знания открывают новые возможности.', 'answer' => 'Knowledge opens new opportunities', 'words' => ['Knowledge', 'opens', 'new', 'opportunities']],
            ],
        ];

        return view('games.sentence', [
            'sentences' => $data[$level],
            'level' => $level,
            'levelName' => $this->levels[$level],
        ]);
    }

    public function typing(string $level = 'easy')
    {
        $this->checkLevel($level);

        $data = [
            'easy' => [
                ['ru' => 'кот', 'answer' => 'cat'],
                ['ru' => 'собака', 'answer' => 'dog'],
                ['ru' => 'книга', 'answer' => 'book'],
                ['ru' => 'яблоко', 'answer' => 'apple'],
            ],
            'medium' => [
                ['ru' => 'учитель', 'answer' => 'teacher'],
                ['ru' => 'школа', 'answer' => 'school'],
                ['ru' => 'семья', 'answer' => 'family'],
                ['ru' => 'завтрак', 'answer' => 'breakfast'],
            ],
            'hard' => [
                ['ru' => 'знание', 'answer' => 'knowledge'],
                ['ru' => 'окружающая среда', 'answer' => 'environment'],
                ['ru' => 'ответственность', 'answer' => 'responsibility'],
                ['ru' => 'достижение', 'answer' => 'achievement'],
            ],
        ];

        return view('games.typing', [
            'items' => $data[$level],
            'level' => $level,
            'levelName' => $this->levels[$level],
            'time' => $this->timeForLevel($level),
        ]);
    }

    public function reward(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'game' => ['required', 'string'],
            'level' => ['nullable', 'string'],
            'score' => ['required', 'integer', 'min:0'],
        ]);

        $level = $request->input('level', 'easy');
        $score = (int) $request->score;

        $multiplier = match ($level) {
            'medium' => 2,
            'hard' => 3,
            default => 1,
        };

        $xp = min(90, $score * 5 * $multiplier);
        $coins = min(45, $score * 2 * $multiplier);

        $user->xp += $xp;
        $user->coins += $coins;
        $user->level = max(1, intdiv((int) $user->xp, 100) + 1);
        $user->save();

        if (class_exists(\App\Services\AchievementService::class)) {
            $unlockedAchievements = app(\App\Services\AchievementService::class)->check($user);

            if (count($unlockedAchievements) > 0) {
                session()->flash('achievement_unlocked', [
                    'icon' => $unlockedAchievements[0]->icon,
                    'title' => $unlockedAchievements[0]->title,
                    'description' => $unlockedAchievements[0]->description,
                ]);
            }
        }

        return response()->json([
            'ok' => true,
            'xp' => $xp,
            'coins' => $coins,
            'message' => "+{$xp} XP и +{$coins} монет",
        ]);
    }

    private function checkLevel(string $level): void
    {
        abort_unless(array_key_exists($level, $this->levels), 404);
    }

    private function timeForLevel(string $level): int
    {
        return match ($level) {
            'medium' => 25,
            'hard' => 20,
            default => 30,
        };
    }
}