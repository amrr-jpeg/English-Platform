<?php

namespace App\Http\Controllers;

use App\Models\UserExercise;
use Illuminate\Support\Facades\Auth;

class MistakeController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $mistakes = UserExercise::where('user_id', $user->id)
            ->where('is_correct', false)
            ->with('exercise.lesson')
            ->latest()
            ->get()
            ->unique('exercise_id');

        return view('mistakes.index', compact('mistakes'));
    }
}