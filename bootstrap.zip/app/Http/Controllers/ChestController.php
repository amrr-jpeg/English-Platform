<?php

namespace App\Http\Controllers;

use App\Models\ChestOpen;
use Illuminate\Support\Facades\Auth;

class ChestController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $openedToday = ChestOpen::where('user_id', $user->id)
            ->whereDate('created_at', today())
            ->exists();

        $history = ChestOpen::where('user_id', $user->id)
            ->latest()
            ->limit(10)
            ->get();

        return view('chests.index', compact('openedToday', 'history'));
    }

    public function open()
    {
        $user = Auth::user();

        $openedToday = ChestOpen::where('user_id', $user->id)
            ->whereDate('created_at', today())
            ->exists();

        if ($openedToday) {
            return back()->with('error', 'Сегодня сундук уже открыт 😅');
        }

        $rewards = [
            ['type' => 'coins', 'amount' => 15, 'label' => '+15 монет 🪙'],
            ['type' => 'coins', 'amount' => 30, 'label' => '+30 монет 🪙'],
            ['type' => 'xp', 'amount' => 25, 'label' => '+25 XP ✨'],
            ['type' => 'xp', 'amount' => 50, 'label' => '+50 XP ✨'],
            ['type' => 'mixed', 'amount' => 40, 'label' => '+20 XP и +20 монет 🎁'],
        ];

        $reward = $rewards[array_rand($rewards)];

        if ($reward['type'] === 'coins') {
            $user->coins += $reward['amount'];
        }

        if ($reward['type'] === 'xp') {
            $user->xp += $reward['amount'];
        }

        if ($reward['type'] === 'mixed') {
            $user->xp += 20;
            $user->coins += 20;
        }

        $user->level = max(1, intdiv((int) $user->xp, 100) + 1);
        $user->save();

        ChestOpen::create([
            'user_id' => $user->id,
            'reward_type' => $reward['type'],
            'reward_amount' => $reward['amount'],
            'reward_label' => $reward['label'],
        ]);

        return back()->with('success', 'Сундук открыт! Награда: ' . $reward['label']);
    }
}