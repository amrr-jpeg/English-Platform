<?php

namespace App\Http\Controllers;

use App\Models\Achievement;
use App\Models\UserAchievement;
use App\Models\UserExercise;
use App\Models\UserLesson;
use App\Models\ChestOpen;
use Illuminate\Support\Facades\Auth;

class ProfilePageController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $completedLessons = UserLesson::where('user_id', $user->id)
            ->where('is_completed', true)
            ->count();

        $totalAnswers = UserExercise::where('user_id', $user->id)->count();

        $correctAnswers = UserExercise::where('user_id', $user->id)
            ->where('is_correct', true)
            ->count();

        $accuracy = $totalAnswers > 0
            ? round(($correctAnswers / $totalAnswers) * 100)
            : 0;

        $achievementIds = UserAchievement::where('user_id', $user->id)
            ->pluck('achievement_id')
            ->toArray();

        $achievements = Achievement::whereIn('id', $achievementIds)
            ->limit(6)
            ->get();

        $lastChests = ChestOpen::where('user_id', $user->id)
            ->latest()
            ->limit(5)
            ->get();

        return view('profile-page.index', compact(
            'user',
            'completedLessons',
            'totalAnswers',
            'correctAnswers',
            'accuracy',
            'achievements',
            'lastChests'
        ));
    }
}