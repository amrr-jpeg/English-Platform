<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\RegistrationCodeMail;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;

class RegisterVerificationController extends Controller
{
    public function show(Request $request): View|RedirectResponse
    {
        if (! session('registration_user_id')) {
            return redirect()->route('register');
        }

        return view('auth.register-verify');
    }

    public function verify(Request $request): RedirectResponse
    {
        $request->validate(
            [
                'code' => ['required', 'digits:6'],
            ],
            [
                'code.required' => 'Введите код.',
                'code.digits' => 'Код должен состоять из 6 цифр.',
            ]
        );

        $user = User::find(session('registration_user_id'));

        if (! $user) {
            return redirect()->route('register')
                ->withErrors(['email' => 'Пользователь не найден.']);
        }

        if ($user->is_registration_verified) {
            Auth::login($user);
            session()->forget('registration_user_id');

            return redirect()->route('dashboard');
        }

        if (! $user->registration_code || ! $user->registration_code_expires_at) {
            return back()->withErrors([
                'code' => 'Код отсутствует. Запросите новый.',
            ]);
        }

        if ($user->registration_code_expires_at->isPast()) {
            return back()->withErrors([
                'code' => 'Срок действия кода истёк. Запросите новый.',
            ]);
        }

        if ($request->code !== $user->registration_code) {
            return back()->withErrors([
                'code' => 'Неверный код подтверждения.',
            ]);
        }

        $user->update([
            'is_registration_verified' => true,
            'registration_code' => null,
            'registration_code_expires_at' => null,
            'email_verified_at' => now(),
        ]);

        Auth::login($user);
        session()->forget('registration_user_id');
        $request->session()->regenerate();

        return redirect()->route('dashboard')
            ->with('status', 'Регистрация успешно подтверждена.');
    }

    public function resend(Request $request): RedirectResponse
    {
        $user = User::find(session('registration_user_id'));

        if (! $user) {
            return redirect()->route('register');
        }

        $code = (string) random_int(100000, 999999);

        $user->update([
            'registration_code' => $code,
            'registration_code_expires_at' => now()->addMinutes(10),
        ]);

        Mail::to($user->email)->send(new RegistrationCodeMail($user, $code));

        return back()->with('status', 'Новый код отправлен на почту.');
    }
}