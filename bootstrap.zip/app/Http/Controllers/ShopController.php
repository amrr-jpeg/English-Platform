<?php

namespace App\Http\Controllers;

use App\Models\UserShopItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ShopController extends Controller
{
    private array $items = [
        ['key' => 'hat_crown', 'name' => 'Корона', 'description' => 'Для настоящего короля английского.', 'type' => 'hat', 'price' => 40, 'icon' => '👑'],
        ['key' => 'hat_cap', 'name' => 'Кепка', 'description' => 'Стильный образ для учёбы.', 'type' => 'hat', 'price' => 25, 'icon' => '🧢'],
        ['key' => 'hat_grad', 'name' => 'Шапочка выпускника', 'description' => 'Идеально для дипломного проекта.', 'type' => 'hat', 'price' => 50, 'icon' => '🎓'],

        ['key' => 'acc_glasses', 'name' => 'Очки', 'description' => 'Добавляют +100 к умному виду.', 'type' => 'accessory', 'price' => 35, 'icon' => '😎'],
        ['key' => 'acc_star', 'name' => 'Звезда', 'description' => 'Покажи, что ты лучший ученик.', 'type' => 'accessory', 'price' => 30, 'icon' => '⭐'],
        ['key' => 'acc_fire', 'name' => 'Огонёк', 'description' => 'Для тех, кто держит серию.', 'type' => 'accessory', 'price' => 45, 'icon' => '🔥'],

        ['key' => 'effect_sparkles', 'name' => 'Сияние', 'description' => 'Вокруг персонажа появляются искры.', 'type' => 'effect', 'price' => 60, 'icon' => '✨'],
        ['key' => 'effect_magic', 'name' => 'Магия', 'description' => 'Волшебное свечение вокруг персонажа.', 'type' => 'effect', 'price' => 70, 'icon' => '🔮'],
        ['key' => 'effect_fire', 'name' => 'Огненная аура', 'description' => 'Максимально эпичный эффект.', 'type' => 'effect', 'price' => 80, 'icon' => '🔥'],
        ['key' => 'effect_stars', 'name' => 'Звёздный след', 'description' => 'Красивые звёзды вокруг персонажа.', 'type' => 'effect', 'price' => 90, 'icon' => '🌟'],

        ['key' => 'bg_space', 'name' => 'Космос', 'description' => 'Профиль с космическим фоном.', 'type' => 'background', 'price' => 70, 'icon' => '🌌'],
        ['key' => 'bg_sunset', 'name' => 'Закат', 'description' => 'Тёплый фон профиля.', 'type' => 'background', 'price' => 70, 'icon' => '🌅'],
        ['key' => 'bg_forest', 'name' => 'Лес', 'description' => 'Спокойный зелёный фон.', 'type' => 'background', 'price' => 70, 'icon' => '🌲'],

        ['key' => 'frame_gold', 'name' => 'Золотая рамка', 'description' => 'Премиальная рамка персонажа.', 'type' => 'frame', 'price' => 85, 'icon' => '🟨'],
        ['key' => 'frame_neon', 'name' => 'Неоновая рамка', 'description' => 'Яркая светящаяся рамка.', 'type' => 'frame', 'price' => 95, 'icon' => '💠'],
        ['key' => 'frame_rainbow', 'name' => 'Радужная рамка', 'description' => 'Самая заметная рамка.', 'type' => 'frame', 'price' => 110, 'icon' => '🌈'],
    ];

    public function index()
    {
        $user = Auth::user();

        $owned = UserShopItem::where('user_id', $user->id)
            ->pluck('item_key')
            ->toArray();

        $items = collect($this->items)->groupBy('type');

        return view('shop', compact('user', 'items', 'owned'));
    }

    public function buy(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'item_key' => ['required', 'string'],
        ]);

        $item = $this->findItem($request->item_key);

        if (!$item) {
            return back()->with('error', 'Такого предмета нет.');
        }

        $alreadyOwned = UserShopItem::where('user_id', $user->id)
            ->where('item_key', $item['key'])
            ->exists();

        if ($alreadyOwned) {
            return back()->with('info', 'Этот предмет уже куплен ✅');
        }

        if ($user->coins < $item['price']) {
            return back()->with('error', 'Не хватает монет 😅');
        }

        DB::transaction(function () use ($user, $item) {
            $user->coins -= $item['price'];
            $user->save();

            UserShopItem::create([
                'user_id' => $user->id,
                'item_key' => $item['key'],
            ]);
        });

        return back()->with('success', 'Предмет куплен! Теперь его можно выбрать ✨');
    }

    public function equip(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'item_key' => ['required', 'string'],
        ]);

        $item = $this->findItem($request->item_key);

        if (!$item) {
            return back()->with('error', 'Такого предмета нет.');
        }

        $owned = UserShopItem::where('user_id', $user->id)
            ->where('item_key', $item['key'])
            ->exists();

        if (!$owned) {
            return back()->with('error', 'Сначала нужно купить этот предмет.');
        }

        $column = match ($item['type']) {
            'hat' => 'equipped_hat',
            'accessory' => 'equipped_accessory',
            'effect' => 'equipped_effect',
            'background' => 'profile_background',
            'frame' => 'profile_frame',
            default => null,
        };

        if (!$column) {
            return back()->with('error', 'Неверный тип предмета.');
        }

        $user->{$column} = $user->{$column} === $item['key'] ? null : $item['key'];
        $user->save();

        return back()->with('success', $user->{$column} ? 'Предмет выбран ✅' : 'Предмет снят');
    }

    private function findItem(string $key): ?array
    {
        foreach ($this->items as $item) {
            if ($item['key'] === $key) {
                return $item;
            }
        }

        return null;
    }
}