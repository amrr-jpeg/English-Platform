<?php

namespace App\Http\Controllers;

use App\Models\Exercise;
use App\Models\UserExercise;
use App\Models\UserLesson;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class StatsController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $totalAnswers = UserExercise::where('user_id', $user->id)->count();

        $correctAnswers = UserExercise::where('user_id', $user->id)
            ->where('is_correct', true)
            ->count();

        $accuracy = $totalAnswers > 0
            ? round(($correctAnswers / $totalAnswers) * 100)
            : 0;

        $completedLessons = UserLesson::where('user_id', $user->id)
            ->where('is_completed', true)
            ->count();

        $learnedWords = UserExercise::where('user_id', $user->id)
            ->where('is_correct', true)
            ->whereHas('exercise', function ($q) {
                $q->whereNotNull('answer')->where('answer', '!=', '');
            })
            ->with('exercise')
            ->get()
            ->pluck('exercise.answer')
            ->filter()
            ->unique()
            ->count();

        $chart = [];

        for ($i = 6; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i);

            $count = UserExercise::where('user_id', $user->id)
                ->where('is_correct', true)
                ->whereDate('created_at', $date->toDateString())
                ->count();

            $chart[] = [
                'label' => $date->format('d.m'),
                'xp' => $count * 10,
            ];
        }

        $maxXp = max(10, collect($chart)->max('xp'));

        return view('stats.index', compact(
            'user',
            'totalAnswers',
            'correctAnswers',
            'accuracy',
            'completedLessons',
            'learnedWords',
            'chart',
            'maxXp'
        ));
    }
}