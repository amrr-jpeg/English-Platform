<?php

namespace App\Http\Controllers;

use App\Models\Lesson;
use App\Models\UserLesson;
use Illuminate\Support\Facades\Auth;

class LessonController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $lessons = Lesson::where('is_active', true)
            ->orderBy('order')
            ->get();

        $progress = UserLesson::where('user_id', $user->id)
            ->get()
            ->keyBy('lesson_id');

        // Открытие уроков: первый всегда, следующий — если предыдущий завершён
        $unlockedLessonIds = [];
        foreach ($lessons as $i => $lesson) {
            if ($i === 0) {
                $unlockedLessonIds[] = $lesson->id;
                continue;
            }

            $prev = $lessons[$i - 1];
            $prevProg = $progress->get($prev->id);

            if ($prevProg && $prevProg->is_completed) {
                $unlockedLessonIds[] = $lesson->id;
            }
        }

        return view('dashboard', compact('lessons','progress','unlockedLessonIds','user'));
    }

    public function show(Lesson $lesson)
    {
        $user = Auth::user();

        $lesson->load(['exercises' => fn($q) => $q->orderBy('order')]);

        $userLesson = UserLesson::firstOrCreate(
            ['user_id' => $user->id, 'lesson_id' => $lesson->id],
            ['completed_exercises' => 0, 'total_exercises' => $lesson->exercises->count(), 'is_completed' => false]
        );

        $userLesson->total_exercises = $lesson->exercises->count();
        $userLesson->save();

        $done = $user->userExercises()
            ->whereIn('exercise_id', $lesson->exercises->pluck('id'))
            ->get()
            ->keyBy('exercise_id');

        return view('lessons.show', compact('lesson','userLesson','done','user'));
    }
}
