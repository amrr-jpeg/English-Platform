<?php

namespace App\Http\Controllers;

use App\Models\Exercise;
use App\Models\UserExercise;
use App\Models\UserLesson;
use App\Models\User;
use App\Services\AchievementService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ExerciseController extends Controller
{
    public function submit(Request $request, Exercise $exercise, AchievementService $achievementService)
    {
        $user = Auth::user();

        $request->validate([
            'answer' => ['required', 'string', 'max:1000'],
        ]);

        $existing = UserExercise::where('user_id', $user->id)
            ->where('exercise_id', $exercise->id)
            ->first();

        if ($existing && $existing->is_correct) {
            return back()->with('info', 'Ты уже решил(а) это упражнение ✅');
        }

        $userAnswer = trim((string) $request->input('answer'));
        $isCorrect = false;

        if (in_array($exercise->type, ['choice', 'input', 'scramble'])) {
            $isCorrect = $this->normalize($userAnswer) === $this->normalize((string) $exercise->answer);
        }

        if ($exercise->type === 'drag_word') {
            $correct = (string) ($exercise->data['answer'] ?? $exercise->answer ?? '');
            $isCorrect = $this->normalize($userAnswer) === $this->normalize($correct);
        }

        if ($exercise->type === 'drag_sentence') {
            $correct = (string) ($exercise->data['answer'] ?? $exercise->answer ?? '');
            $isCorrect = $this->normalizeSentence($userAnswer) === $this->normalizeSentence($correct);
        }

        if ($exercise->type === 'syllables') {
            $correct = (string) ($exercise->data['answer'] ?? $exercise->answer ?? '');
            $isCorrect = $this->normalize($userAnswer) === $this->normalize($correct);
        }

        if ($exercise->type === 'pairs') {
            $pairs = $request->input('pairs', []);
            $truePairs = $exercise->data['true_pairs'] ?? [];

            $isCorrect = !empty($truePairs) && $pairs == $truePairs;
            $userAnswer = json_encode($pairs, JSON_UNESCAPED_UNICODE);
        }

        if ($exercise->type === 'flashcards') {
            $isCorrect = $userAnswer === 'done';
        }

        UserExercise::updateOrCreate(
            [
                'user_id' => $user->id,
                'exercise_id' => $exercise->id,
            ],
            [
                'is_correct' => $isCorrect,
                'user_answer' => $userAnswer,
            ]
        );

        if (!$isCorrect) {
            return back()->with('error', 'Почти! Попробуй ещё раз 🙂');
        }

        $user->xp += (int) $exercise->xp_reward;
        $user->coins += (int) $exercise->coin_reward;
        $user->level = max(1, intdiv((int) $user->xp, 100) + 1);

        $streakChanged = $this->updateStreak($user);

        if ($streakChanged && $user->streak > 0 && $user->streak % 3 === 0) {
            $user->coins += 5;
        }

        $user->save();

        $this->updateLessonProgress($user, $exercise->lesson_id);

        $user->refresh();

        $unlockedAchievements = $achievementService->check($user);

        if (count($unlockedAchievements) > 0) {
            session()->flash('achievement_unlocked', [
                'icon' => $unlockedAchievements[0]->icon,
                'title' => $unlockedAchievements[0]->title,
                'description' => $unlockedAchievements[0]->description,
            ]);
        }

        $msg = 'Правильно! 🎉 +XP и монеты получены!';

        if ($exercise->type === 'flashcards') {
            $msg = 'Отлично! Карточки изучены 🎴';
        }

        if ($streakChanged) {
            $msg .= ' 🔥 Серия: ' . $user->streak;
        }

        return back()->with('success', $msg);
    }

    private function normalize(string $value): string
    {
        return mb_strtolower(trim($value));
    }

    private function normalizeSentence(string $value): string
    {
        $value = mb_strtolower(trim($value));
        $value = preg_replace('/\s+/u', ' ', $value);
        $value = preg_replace('/[.!?,;:]+/u', '', $value);

        return trim($value);
    }

    private function updateStreak(User $user): bool
    {
        $today = now()->toDateString();

        if ($user->last_activity_date && $user->last_activity_date->toDateString() === $today) {
            return false;
        }

        $yesterday = now()->subDay()->toDateString();

        if ($user->last_activity_date && $user->last_activity_date->toDateString() === $yesterday) {
            $user->streak = ((int) $user->streak) + 1;
        } else {
            $user->streak = 1;
        }

        $user->best_streak = max((int) $user->best_streak, (int) $user->streak);
        $user->last_activity_date = $today;

        return true;
    }

    private function updateLessonProgress(User $user, int $lessonId): void
    {
        $userLesson = UserLesson::firstOrCreate(
            [
                'user_id' => $user->id,
                'lesson_id' => $lessonId,
            ],
            [
                'completed_exercises' => 0,
                'total_exercises' => 0,
                'is_completed' => false,
            ]
        );

        $correctCount = UserExercise::where('user_id', $user->id)
            ->where('is_correct', true)
            ->whereHas('exercise', function ($q) use ($lessonId) {
                $q->where('lesson_id', $lessonId);
            })
            ->count();

        $total = Exercise::where('lesson_id', $lessonId)->count();

        $userLesson->completed_exercises = $correctCount;
        $userLesson->total_exercises = $total;
        $userLesson->is_completed = ($total > 0 && $correctCount >= $total);
        $userLesson->save();
    }
}