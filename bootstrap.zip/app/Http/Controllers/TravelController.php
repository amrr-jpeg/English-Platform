<?php

namespace App\Http\Controllers;

use App\Models\Exercise;
use App\Models\Lesson;
use App\Models\UserLesson;
use Illuminate\Support\Facades\Auth;

class TravelController extends Controller
{
    public function index()
    {
        $lessons = Lesson::where('category', 'Travel English')
            ->where('is_active', true)
            ->orderBy('order')
            ->withCount('exercises')
            ->get();

        $completedIds = UserLesson::where('user_id', Auth::id())
            ->where('is_completed', true)
            ->pluck('lesson_id')
            ->toArray();

        return view('travel.index', compact('lessons', 'completedIds'));
    }

    public function games()
    {
        $games = [
            [
                'title' => 'Аэропорт',
                'icon' => '✈️',
                'description' => 'Слова и фразы для регистрации, багажа и посадки.',
                'questions' => [
                    ['q' => 'boarding pass', 'a' => 'посадочный талон'],
                    ['q' => 'luggage', 'a' => 'багаж'],
                    ['q' => 'gate', 'a' => 'выход на посадку'],
                ],
            ],
            [
                'title' => 'Отель',
                'icon' => '🏨',
                'description' => 'Фразы для заселения, брони и вопросов на ресепшене.',
                'questions' => [
                    ['q' => 'reservation', 'a' => 'бронь'],
                    ['q' => 'check-in', 'a' => 'заселение'],
                    ['q' => 'room key', 'a' => 'ключ от номера'],
                ],
            ],
            [
                'title' => 'Ресторан',
                'icon' => '🍽️',
                'description' => 'Заказ еды, счёт, меню и общение с официантом.',
                'questions' => [
                    ['q' => 'menu', 'a' => 'меню'],
                    ['q' => 'bill', 'a' => 'счёт'],
                    ['q' => 'water', 'a' => 'вода'],
                ],
            ],
        ];

        return view('travel.games', compact('games'));
    }
}