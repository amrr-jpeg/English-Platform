<?php

namespace App\Http\Controllers;

use App\Models\ExamResult;
use App\Models\Lesson;
use App\Models\UserLesson;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ExamController extends Controller
{
    private array $exams = [
        1 => [
            'title' => 'Экзамен 1',
            'description' => 'Проверка после уроков 1–10.',
            'from' => 1,
            'to' => 10,
            'time' => 180,
        ],
        2 => [
            'title' => 'Экзамен 2',
            'description' => 'Проверка после уроков 11–20.',
            'from' => 11,
            'to' => 20,
            'time' => 210,
        ],
        3 => [
            'title' => 'Экзамен 3',
            'description' => 'Финальная проверка после уроков 21–30.',
            'from' => 21,
            'to' => 30,
            'time' => 240,
        ],
    ];

    public function intro()
    {
        $user = Auth::user();

        $exams = [];

        foreach ($this->exams as $number => $exam) {
            $lessonIds = Lesson::whereBetween('order', [$exam['from'], $exam['to']])
                ->pluck('id');

            $completedCount = UserLesson::where('user_id', $user->id)
                ->whereIn('lesson_id', $lessonIds)
                ->where('is_completed', true)
                ->count();

            $totalLessons = $lessonIds->count();

            $exams[$number] = [
                ...$exam,
                'number' => $number,
                'completed' => $completedCount,
                'total' => $totalLessons,
                'unlocked' => $totalLessons > 0 && $completedCount >= $totalLessons,
            ];
        }

        return view('exam.intro', compact('exams'));
    }

    public function start(int $exam)
    {
        abort_unless(isset($this->exams[$exam]), 404);

        if (!$this->isExamUnlocked($exam)) {
            return redirect()
                ->route('exam.intro')
                ->with('error', 'Этот экзамен пока недоступен. Сначала пройди нужные уроки.');
        }

        return view('exam.start', [
            'examNumber' => $exam,
            'examData' => $this->exams[$exam],
            'questions' => $this->questions($exam),
            'timeLimit' => $this->exams[$exam]['time'],
        ]);
    }

    public function submit(Request $request, int $exam)
    {
        abort_unless(isset($this->exams[$exam]), 404);

        $user = Auth::user();
        $questions = collect($this->questions($exam));

        $answers = $request->input('answers', []);
        $warnings = (int) $request->input('warnings', 0);
        $autoFinished = $request->boolean('auto_finished');

        $score = 0;

        foreach ($questions as $question) {
            $given = $answers[$question['id']] ?? null;

            if ($given === $question['answer']) {
                $score++;
            }
        }

        $total = $questions->count();
        $percent = $total > 0 ? round(($score / $total) * 100) : 0;

        $xp = $score * 12 * $exam;
        $coins = $score * 5 * $exam;

        if ($warnings >= 3 || $autoFinished) {
            $xp = 0;
            $coins = 0;
        }

        $user->xp += $xp;
        $user->coins += $coins;
        $user->level = max(1, intdiv((int) $user->xp, 100) + 1);
        $user->save();

        if (class_exists(ExamResult::class)) {
            ExamResult::create([
                'user_id' => $user->id,
                'score' => $score,
                'total' => $total,
                'warnings' => $warnings,
                'auto_finished' => $warnings >= 3 || $autoFinished,
                'xp_reward' => $xp,
                'coin_reward' => $coins,
            ]);
        }

        return view('exam.result', compact(
            'exam',
            'score',
            'total',
            'percent',
            'warnings',
            'xp',
            'coins',
            'autoFinished'
        ));
    }

    private function isExamUnlocked(int $exam): bool
    {
        $user = Auth::user();
        $examData = $this->exams[$exam];

        $lessonIds = Lesson::whereBetween('order', [$examData['from'], $examData['to']])
            ->pluck('id');

        if ($lessonIds->isEmpty()) {
            return false;
        }

        $completedCount = UserLesson::where('user_id', $user->id)
            ->whereIn('lesson_id', $lessonIds)
            ->where('is_completed', true)
            ->count();

        return $completedCount >= $lessonIds->count();
    }

    private function questions(int $exam): array
    {
        return match ($exam) {
            1 => [
                ['id' => 1, 'question' => 'Как переводится "cat"?', 'options' => ['кот', 'собака', 'книга', 'яблоко'], 'answer' => 'кот'],
                ['id' => 2, 'question' => 'Как по-английски "собака"?', 'options' => ['dog', 'cat', 'book', 'water'], 'answer' => 'dog'],
                ['id' => 3, 'question' => 'Как переводится "apple"?', 'options' => ['яблоко', 'молоко', 'дом', 'окно'], 'answer' => 'яблоко'],
                ['id' => 4, 'question' => 'Как по-английски "книга"?', 'options' => ['book', 'pen', 'desk', 'school'], 'answer' => 'book'],
                ['id' => 5, 'question' => 'Как переводится "green"?', 'options' => ['зелёный', 'красный', 'синий', 'чёрный'], 'answer' => 'зелёный'],
                ['id' => 6, 'question' => 'Как по-английски "солнце"?', 'options' => ['sun', 'rain', 'snow', 'tree'], 'answer' => 'sun'],
                ['id' => 7, 'question' => 'Как переводится "mother"?', 'options' => ['мама', 'папа', 'сестра', 'брат'], 'answer' => 'мама'],
                ['id' => 8, 'question' => 'Как по-английски "дом"?', 'options' => ['house', 'room', 'window', 'door'], 'answer' => 'house'],
                ['id' => 9, 'question' => 'Как переводится "read"?', 'options' => ['читать', 'бегать', 'играть', 'прыгать'], 'answer' => 'читать'],
                ['id' => 10, 'question' => 'Как по-английски "три"?', 'options' => ['three', 'two', 'one', 'ten'], 'answer' => 'three'],
            ],

            2 => [
                ['id' => 1, 'question' => 'Как переводится "teacher"?', 'options' => ['учитель', 'врач', 'водитель', 'ученик'], 'answer' => 'учитель'],
                ['id' => 2, 'question' => 'Как по-английски "город"?', 'options' => ['city', 'street', 'shop', 'park'], 'answer' => 'city'],
                ['id' => 3, 'question' => 'Как переводится "train"?', 'options' => ['поезд', 'машина', 'автобус', 'самолёт'], 'answer' => 'поезд'],
                ['id' => 4, 'question' => 'Как по-английски "утро"?', 'options' => ['morning', 'evening', 'today', 'night'], 'answer' => 'morning'],
                ['id' => 5, 'question' => 'Как переводится "music"?', 'options' => ['музыка', 'спорт', 'рисование', 'игра'], 'answer' => 'музыка'],
                ['id' => 6, 'question' => 'Как по-английски "гора"?', 'options' => ['mountain', 'river', 'tree', 'forest'], 'answer' => 'mountain'],
                ['id' => 7, 'question' => 'Как переводится "happy"?', 'options' => ['счастливый', 'грустный', 'злой', 'усталый'], 'answer' => 'счастливый'],
                ['id' => 8, 'question' => 'Как по-английски "почему"?', 'options' => ['why', 'what', 'where', 'when'], 'answer' => 'why'],
                ['id' => 9, 'question' => 'Выбери перевод "She reads a book"', 'options' => ['Она читает книгу', 'Он играет дома', 'Мы идём в школу', 'Я люблю музыку'], 'answer' => 'Она читает книгу'],
                ['id' => 10, 'question' => 'Как переводится "friend"?', 'options' => ['друг', 'семья', 'город', 'еда'], 'answer' => 'друг'],
            ],

            3 => [
                ['id' => 1, 'question' => 'Как переводится "knowledge"?', 'options' => ['знание', 'успех', 'цель', 'общение'], 'answer' => 'знание'],
                ['id' => 2, 'question' => 'Как по-английски "образование"?', 'options' => ['education', 'environment', 'technology', 'achievement'], 'answer' => 'education'],
                ['id' => 3, 'question' => 'Как переводится "environment"?', 'options' => ['окружающая среда', 'ответственность', 'развитие', 'безопасность'], 'answer' => 'окружающая среда'],
                ['id' => 4, 'question' => 'Как по-английски "ответственность"?', 'options' => ['responsibility', 'opportunity', 'communication', 'development'], 'answer' => 'responsibility'],
                ['id' => 5, 'question' => 'Как переводится "achievement"?', 'options' => ['достижение', 'ошибка', 'попытка', 'урок'], 'answer' => 'достижение'],
                ['id' => 6, 'question' => 'Как по-английски "развитие"?', 'options' => ['development', 'future', 'career', 'message'], 'answer' => 'development'],
                ['id' => 7, 'question' => 'Как переводится "communication"?', 'options' => ['общение', 'будущее', 'защита', 'опасность'], 'answer' => 'общение'],
                ['id' => 8, 'question' => 'Как по-английски "возможность"?', 'options' => ['opportunity', 'safety', 'danger', 'protection'], 'answer' => 'opportunity'],
                ['id' => 9, 'question' => 'Выбери перевод "Knowledge opens new opportunities"', 'options' => ['Знания открывают новые возможности', 'Английский помогает учиться', 'Ответственность важна для успеха', 'Технологии развиваются быстро'], 'answer' => 'Знания открывают новые возможности'],
                ['id' => 10, 'question' => 'Выбери перевод "Responsibility is important for success"', 'options' => ['Ответственность важна для успеха', 'Знания открывают возможности', 'Общение помогает людям', 'Развитие требует времени'], 'answer' => 'Ответственность важна для успеха'],
            ],

            default => [],
        };
    }
}