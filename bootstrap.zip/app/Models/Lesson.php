<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Lesson extends Model
{
    protected $fillable = [
        'order',
        'title',
        'description',
        'category',
        'level',
        'theory',
        'is_active',
    ];

    public function exercises(): HasMany
    {
        return $this->hasMany(Exercise::class)->orderBy('order');
    }

    public function userLessons()
{
    return $this->hasMany(\App\Models\UserLesson::class);
}
}
