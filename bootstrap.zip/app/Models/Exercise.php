<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Exercise extends Model
{
    protected $fillable = [
        'lesson_id',
        'type',
        'question',
        'options',
        'answer',
        'xp_reward',
        'coin_reward',
        'order',
        'data',
    ];

    protected $casts = [
        'options' => 'array',
        'data' => 'array',
    ];

    public function lesson()
{
    return $this->belongsTo(\App\Models\Lesson::class);
}
    
}
