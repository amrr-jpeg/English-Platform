<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserExercise extends Model
{
    protected $fillable = [
        'user_id','exercise_id','is_correct','user_answer'
    ];

    public function exercise()
{
    return $this->belongsTo(\App\Models\Exercise::class);
}
}
