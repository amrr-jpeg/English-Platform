<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',

        'registration_code',
        'registration_code_expires_at',
        'is_registration_verified',

        'xp',
        'level',
        'coins',
        'skin',
        'streak',
        'best_streak',
        'last_activity_date',
        'is_admin',
        'equipped_hat_id',
        'equipped_glasses_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'registration_code',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'registration_code_expires_at' => 'datetime',
        'is_registration_verified' => 'boolean',
        'last_activity_date' => 'date',
        'is_admin' => 'boolean',
    ];

    

    public function userExercises(): HasMany
    {
        return $this->hasMany(UserExercise::class);
    }

    public function userLessons(): HasMany
    {
        return $this->hasMany(UserLesson::class);
    }

    public function userItems(): HasMany
    {
        return $this->hasMany(UserItem::class);
    }
}