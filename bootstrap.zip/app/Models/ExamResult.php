<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExamResult extends Model
{
    protected $fillable = [
        'user_id',
        'score',
        'total',
        'warnings',
        'auto_finished',
        'xp_reward',
        'coin_reward',
    ];
}