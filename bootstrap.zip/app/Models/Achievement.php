<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Achievement extends Model
{
    protected $fillable = [
        'key',
        'title',
        'description',
        'icon',
        'reward_xp',
        'reward_coins',
    ];
}