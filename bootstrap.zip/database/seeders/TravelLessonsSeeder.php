<?php

namespace Database\Seeders;

use App\Models\Exercise;
use App\Models\Lesson;
use Illuminate\Database\Seeder;

class TravelLessonsSeeder extends Seeder
{
    public function run(): void
    {
        $lessons = [
            [
                'title' => 'Travel 1: Airport',
                'description' => 'Фразы и слова для аэропорта.',
                'level' => 'easy',
                'words' => [
                    'airport' => 'аэропорт',
                    'ticket' => 'билет',
                    'passport' => 'паспорт',
                    'luggage' => 'багаж',
                ],
            ],
            [
                'title' => 'Travel 2: Hotel',
                'description' => 'Заселение в отель и общение на ресепшене.',
                'level' => 'easy',
                'words' => [
                    'hotel' => 'отель',
                    'reservation' => 'бронь',
                    'room' => 'номер',
                    'key' => 'ключ',
                ],
            ],
            [
                'title' => 'Travel 3: Restaurant',
                'description' => 'Как заказать еду и попросить счёт.',
                'level' => 'easy',
                'words' => [
                    'menu' => 'меню',
                    'water' => 'вода',
                    'bill' => 'счёт',
                    'table' => 'столик',
                ],
            ],
            [
                'title' => 'Travel 4: Taxi',
                'description' => 'Фразы для поездок на такси.',
                'level' => 'medium',
                'words' => [
                    'taxi' => 'такси',
                    'address' => 'адрес',
                    'station' => 'станция',
                    'price' => 'цена',
                ],
            ],
            [
                'title' => 'Travel 5: City',
                'description' => 'Ориентация в городе.',
                'level' => 'medium',
                'words' => [
                    'street' => 'улица',
                    'museum' => 'музей',
                    'map' => 'карта',
                    'square' => 'площадь',
                ],
            ],
            [
                'title' => 'Travel 6: Emergency',
                'description' => 'Важные фразы в экстренных ситуациях.',
                'level' => 'hard',
                'words' => [
                    'help' => 'помощь',
                    'doctor' => 'врач',
                    'police' => 'полиция',
                    'lost' => 'потерялся',
                ],
            ],
        ];

        foreach ($lessons as $index => $item) {
            $order = 100 + $index + 1;

            $lesson = Lesson::updateOrCreate(
                ['order' => $order],
                [
                    'title' => $item['title'],
                    'description' => $item['description'],
                    'level' => $item['level'],
                    'category' => 'Travel English',
                    'is_active' => true,
                ]
            );

            Exercise::where('lesson_id', $lesson->id)->delete();

            $exerciseOrder = 1;

            foreach ($item['words'] as $en => $ru) {
                Exercise::create([
                    'lesson_id' => $lesson->id,
                    'type' => 'choice',
                    'question' => 'Как переводится "' . $en . '"?',
                    'options' => json_encode([$ru, 'дом', 'еда', 'книга'], JSON_UNESCAPED_UNICODE),
                    'answer' => $ru,
                    'order' => $exerciseOrder++,
                    'xp_reward' => 10,
                    'coin_reward' => 3,
                ]);

                Exercise::create([
                    'lesson_id' => $lesson->id,
                    'type' => 'input',
                    'question' => 'Напиши по-английски: ' . $ru,
                    'options' => null,
                    'answer' => $en,
                    'order' => $exerciseOrder++,
                    'xp_reward' => 12,
                    'coin_reward' => 4,
                ]);
            }
        }
    }
}