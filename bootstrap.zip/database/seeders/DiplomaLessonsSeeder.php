<?php

namespace Database\Seeders;

use App\Models\Lesson;
use App\Models\Exercise;
use Illuminate\Database\Seeder;

class DiplomaLessonsSeeder extends Seeder
{
    public function run(): void
    {
        $lessons = [
            // 1-10 EASY
            ['Animals', 'Животные', 'easy', ['cat' => 'кот', 'dog' => 'собака', 'bird' => 'птица']],
            ['Food', 'Еда', 'easy', ['apple' => 'яблоко', 'bread' => 'хлеб', 'milk' => 'молоко']],
            ['School', 'Школа', 'easy', ['book' => 'книга', 'pen' => 'ручка', 'desk' => 'парта']],
            ['Colors', 'Цвета', 'easy', ['red' => 'красный', 'blue' => 'синий', 'green' => 'зелёный']],
            ['Family', 'Семья', 'easy', ['mother' => 'мама', 'father' => 'папа', 'sister' => 'сестра']],
            ['Numbers', 'Числа', 'easy', ['one' => 'один', 'two' => 'два', 'three' => 'три']],
            ['House', 'Дом', 'easy', ['house' => 'дом', 'room' => 'комната', 'window' => 'окно']],
            ['Weather', 'Погода', 'easy', ['sun' => 'солнце', 'rain' => 'дождь', 'snow' => 'снег']],
            ['Body', 'Тело', 'easy', ['head' => 'голова', 'hand' => 'рука', 'eye' => 'глаз']],
            ['Daily actions', 'Ежедневные действия', 'easy', ['run' => 'бегать', 'read' => 'читать', 'play' => 'играть']],

            // 11-20 MEDIUM
            ['Professions', 'Профессии', 'medium', ['teacher' => 'учитель', 'doctor' => 'доктор', 'driver' => 'водитель']],
            ['City', 'Город', 'medium', ['street' => 'улица', 'shop' => 'магазин', 'park' => 'парк']],
            ['Transport', 'Транспорт', 'medium', ['car' => 'машина', 'bus' => 'автобус', 'train' => 'поезд']],
            ['Time', 'Время', 'medium', ['morning' => 'утро', 'evening' => 'вечер', 'today' => 'сегодня']],
            ['Hobbies', 'Хобби', 'medium', ['music' => 'музыка', 'drawing' => 'рисование', 'sport' => 'спорт']],
            ['Nature', 'Природа', 'medium', ['tree' => 'дерево', 'river' => 'река', 'mountain' => 'гора']],
            ['Clothes', 'Одежда', 'medium', ['shirt' => 'рубашка', 'shoes' => 'обувь', 'hat' => 'шапка']],
            ['Emotions', 'Эмоции', 'medium', ['happy' => 'счастливый', 'sad' => 'грустный', 'angry' => 'злой']],
            ['Questions', 'Вопросы', 'medium', ['what' => 'что', 'where' => 'где', 'why' => 'почему']],
            ['Sentences', 'Предложения', 'medium', ['I like English' => 'Я люблю английский', 'She reads a book' => 'Она читает книгу', 'We go to school' => 'Мы ходим в школу']],

            // 21-30 HARD
            ['Knowledge', 'Знания', 'hard', ['knowledge' => 'знание', 'education' => 'образование', 'learning' => 'обучение']],
            ['Environment', 'Окружающая среда', 'hard', ['environment' => 'окружающая среда', 'pollution' => 'загрязнение', 'nature' => 'природа']],
            ['Technology', 'Технологии', 'hard', ['technology' => 'технология', 'computer' => 'компьютер', 'internet' => 'интернет']],
            ['Responsibility', 'Ответственность', 'hard', ['responsibility' => 'ответственность', 'choice' => 'выбор', 'result' => 'результат']],
            ['Achievements', 'Достижения', 'hard', ['achievement' => 'достижение', 'success' => 'успех', 'goal' => 'цель']],
            ['Development', 'Развитие', 'hard', ['development' => 'развитие', 'improvement' => 'улучшение', 'progress' => 'прогресс']],
            ['Communication', 'Коммуникация', 'hard', ['communication' => 'общение', 'message' => 'сообщение', 'conversation' => 'разговор']],
            ['Opportunities', 'Возможности', 'hard', ['opportunity' => 'возможность', 'future' => 'будущее', 'career' => 'карьера']],
            ['Safety', 'Безопасность', 'hard', ['safety' => 'безопасность', 'danger' => 'опасность', 'protection' => 'защита']],
            ['Final practice', 'Итоговая практика', 'hard', ['Learning English helps me develop' => 'Изучение английского помогает мне развиваться', 'Knowledge opens new opportunities' => 'Знания открывают новые возможности', 'Responsibility is important for success' => 'Ответственность важна для успеха']],
        ];

        foreach ($lessons as $index => $item) {
            [$title, $description, $level, $words] = $item;
            $order = $index + 1;

            $lesson = Lesson::updateOrCreate(
                ['order' => $order],
                [
                    'title' => 'Урок ' . $order . ': ' . $title,
                    'description' => $description,
                    'level' => $level,
                    'category' => 'Дипломный курс',
                    'is_active' => true,
                ]
            );

            Exercise::where('lesson_id', $lesson->id)->delete();

            $exerciseOrder = 1;

            foreach ($words as $en => $ru) {
                Exercise::create([
                    'lesson_id' => $lesson->id,
                    'type' => 'choice',
                    'question' => 'Как переводится "' . $en . '"?',
                    'options' => json_encode([$ru, 'дом', 'школа', 'яблоко'], JSON_UNESCAPED_UNICODE),
                    'answer' => $ru,
                    'order' => $exerciseOrder++,
                    'xp_reward' => 10,
                    'coin_reward' => 3,
                ]);

                Exercise::create([
                    'lesson_id' => $lesson->id,
                    'type' => 'input',
                    'question' => 'Напиши по-английски: ' . $ru,
                    'options' => null,
                    'answer' => $en,
                    'order' => $exerciseOrder++,
                    'xp_reward' => 12,
                    'coin_reward' => 4,
                ]);
            }
        }
    }
}