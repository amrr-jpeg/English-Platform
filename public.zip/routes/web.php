<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LessonController;
use App\Http\Controllers\ExerciseController;
use App\Http\Controllers\CharacterController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\AchievementController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\LessonAdminController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\StatsController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\ChestController;
use App\Http\Controllers\MistakeController;
use App\Http\Controllers\ProfilePageController;
use App\Http\Controllers\Admin\AdminStatsController;
use App\Http\Controllers\TravelController;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', [LessonController::class, 'index'])->name('dashboard');
    Route::get('/lessons/{lesson}', [LessonController::class, 'show'])->name('lessons.show');

    Route::post('/exercises/{exercise}/submit', [ExerciseController::class, 'submit'])->name('exercises.submit');

    Route::get('/character', [CharacterController::class, 'index'])->name('character');
    Route::post('/character/buy-skin', [CharacterController::class, 'buySkin'])->name('character.buySkin');

    Route::get('/shop', [ShopController::class,'index'])->name('shop');
    Route::post('/shop/buy', [ShopController::class,'buy'])->name('shop.buy');
    Route::post('/shop/equip', [ShopController::class,'equip'])->name('shop.equip');

    Route::get('/achievements', [AchievementController::class, 'index'])->name('achievements');

    Route::get('/games', [GameController::class, 'index'])->name('games.index');
    Route::get('/games/translation/{level?}', [GameController::class, 'translation'])
    ->name('games.translation');
    Route::get('/games/picture/{level?}', [GameController::class, 'picture'])
    ->name('games.picture');
    Route::get('/games/memory/{level}', [GameController::class, 'memory'])
    ->name('games.memory');
    Route::get('/games/sentence/{level?}', [GameController::class, 'sentence'])
    ->name('games.sentence');
    Route::get('/games/typing/{level?}', [GameController::class, 'typing'])
    ->name('games.typing');
    Route::post('/games/reward', [GameController::class, 'reward'])
    ->name('games.reward');


    Route::get('/stats', [StatsController::class, 'index'])->name('stats.index');

    Route::get('/exam', [ExamController::class, 'intro'])->name('exam.intro');

    Route::get('/exam/{exam}/start', [ExamController::class, 'start'])
    ->whereNumber('exam')
    ->name('exam.start');

    Route::post('/exam/{exam}/submit', [ExamController::class, 'submit'])
    ->whereNumber('exam')
    ->name('exam.submit');

    Route::get('/travel', [TravelController::class, 'index'])->name('travel.index');
    Route::get('/travel/games', [TravelController::class, 'games'])->name('travel.games');
    Route::get('/travel/scenario', function () {
    return view('travel.scenario');
    })->name('travel.scenario');


    Route::get('/chests', [ChestController::class, 'index'])->name('chests.index');
    Route::post('/chests/open', [ChestController::class, 'open'])->name('chests.open');

    Route::get('/mistakes', [MistakeController::class, 'index'])->name('mistakes.index');

    Route::get('/my-profile', [ProfilePageController::class, 'index'])->name('profile.page');
});

Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('admin.index');

    Route::get('/lessons', [LessonAdminController::class, 'index'])->name('admin.lessons');
    Route::get('/lessons/create', [LessonAdminController::class, 'create'])->name('admin.lessons.create');
    Route::post('/lessons', [LessonAdminController::class, 'store'])->name('admin.lessons.store');

    Route::get('/lessons/{lesson}/exercises', [LessonAdminController::class, 'exercises'])->name('admin.exercises');
    Route::put('/lessons/{lesson}', [LessonAdminController::class, 'updateLesson'])->name('admin.lessons.update');

    Route::post('/lessons/{lesson}/exercises', [LessonAdminController::class, 'storeExercise'])->name('admin.exercises.store');
    Route::put('/exercises/{exercise}', [LessonAdminController::class, 'updateExercise'])->name('admin.exercises.update');
    Route::delete('/exercises/{exercise}', [LessonAdminController::class, 'deleteExercise'])->name('admin.exercises.delete');

    Route::get('/lessons/{lesson}/preview', [LessonAdminController::class, 'preview'])->name('admin.lessons.preview');
    Route::get('/stats', [AdminStatsController::class, 'index'])->name('admin.stats');
});

require __DIR__.'/auth.php';