@extends('layouts.kids')

@section('content')
<a class="link" href="{{ route('dashboard') }}">← Назад</a>

<h1 class="h1">Твой персонаж</h1>
<p class="muted">Покупай стили один раз, а потом свободно переключай их.</p>

@if(session('success'))
    <div class="toast toast--ok">{{ session('success') }}</div>
@endif

@if(session('error'))
    <div class="toast toast--bad">{{ session('error') }}</div>
@endif

@if(session('info'))
    <div class="toast">{{ session('info') }}</div>
@endif

<div class="characterGrid">
    <div class="buddy buddy--{{ $user->skin ?? 'blue' }} buddy--big {{ $user->equipped_effect ? 'shopAvatar--' . $user->equipped_effect : '' }}">
    <div class="buddy__glow"></div>

    @if($user->equipped_hat)
        <div class="shopAvatar__hat">
            @if($user->equipped_hat === 'hat_crown') 👑
            @elseif($user->equipped_hat === 'hat_cap') 🧢
            @elseif($user->equipped_hat === 'hat_grad') 🎓
            @endif
        </div>
    @endif

    <div class="buddy__face">
        @if(($user->skin ?? 'blue') === 'pink')
            😊
        @elseif(($user->skin ?? 'blue') === 'green')
            😎
        @else
            😄
        @endif
    </div>

    @if($user->equipped_accessory)
        <div class="shopAvatar__accessory">
            @if($user->equipped_accessory === 'acc_glasses') 😎
            @elseif($user->equipped_accessory === 'acc_star') ⭐
            @elseif($user->equipped_accessory === 'acc_fire') 🔥
            @endif
        </div>
    @endif

    <div class="buddy__name">LVL {{ $user->level }}</div>

    <div class="buddy__skin">
        Текущий стиль:
        <b>
            @if(($user->skin ?? 'blue') === 'pink')
                Розовый
            @elseif(($user->skin ?? 'blue') === 'green')
                Зелёный
            @else
                Синий
            @endif
        </b>
    </div>

    <div class="buddy__mini">XP: {{ $user->xp }} • Монеты: {{ $user->coins }}</div>
</div>

    <div class="card">
        <h2 class="h2">Стили персонажа</h2>

        <div class="skins">
            @foreach($skins as $s)
                @php
                    $isOwned = in_array($s['key'], $ownedSkins);
                    $isSelected = ($user->skin ?? 'blue') === $s['key'];
                @endphp

                <form method="POST" action="{{ route('character.buySkin') }}"
                      class="skinCard {{ $isSelected ? 'skinCard--selected' : '' }}">
                    @csrf

                    <input type="hidden" name="skin" value="{{ $s['key'] }}">

                    <div class="skinPreview skinPreview--{{ $s['key'] }}">
                        <span>{{ $s['emoji'] }}</span>
                    </div>

                    <div class="skinInfo">
                        <div class="skinName">{{ $s['name'] }}</div>

                        <div class="muted small">
                            @if($isSelected)
                                ✅ Сейчас выбран
                            @elseif($isOwned)
                                🔓 Уже куплен
                            @else
                                Цена: {{ $s['price'] }} 🪙
                            @endif
                        </div>
                    </div>

                    @if($isSelected)
                        <button class="btn btn--disabled" type="button" disabled>
                            Выбран
                        </button>
                    @elseif($isOwned)
                        <button class="btn" type="submit">
                            Выбрать
                        </button>
                    @else
                        <button class="btn" type="submit">
                            Купить за {{ $s['price'] }} 🪙
                        </button>
                    @endif
                </form>
            @endforeach
        </div>
    </div>
</div>
@endsection