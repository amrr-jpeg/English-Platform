@extends('layouts.kids')

@section('content')
<div class="hero">
    <div>
        <h1 class="h1">Статистика</h1>
        <p class="muted">Следи за прогрессом, точностью и изученными словами.</p>
    </div>

    <div class="card">
        <div class="h2">LVL {{ $user->level }}</div>
        <div class="muted">текущий уровень</div>
    </div>
</div>

<div class="statsGrid">
    <div class="statCard">
        <div class="statCard__icon">✨</div>
        <div class="statCard__value">{{ $user->xp }}</div>
        <div class="statCard__label">XP всего</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">📚</div>
        <div class="statCard__value">{{ $completedLessons }}</div>
        <div class="statCard__label">уроков пройдено</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">🧠</div>
        <div class="statCard__value">{{ $learnedWords }}</div>
        <div class="statCard__label">слов изучено</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">🎯</div>
        <div class="statCard__value">{{ $accuracy }}%</div>
        <div class="statCard__label">точность ответов</div>
    </div>
</div>

<div class="card statsChartCard">
    <div class="builderSection__head">
        <div>
            <h2 class="h2">График XP за 7 дней</h2>
            <p class="muted">График строится по правильно выполненным упражнениям.</p>
        </div>
    </div>

    <div class="xpChart">
        @foreach($chart as $day)
            @php
                $height = max(8, intval(($day['xp'] / $maxXp) * 180));
            @endphp

            <div class="xpChart__item">
                <div class="xpChart__barWrap">
                    <div class="xpChart__bar" style="height: {{ $height }}px;">
                        <span>{{ $day['xp'] }}</span>
                    </div>
                </div>
                <div class="xpChart__label">{{ $day['label'] }}</div>
            </div>
        @endforeach
    </div>
</div>

<div class="card">
    <h2 class="h2">Ответы</h2>

    <div class="progress">
        <div class="progress__bar" style="width: {{ $accuracy }}%"></div>
    </div>

    <p class="muted">
        Правильных ответов: {{ $correctAnswers }} из {{ $totalAnswers }}.
    </p>
</div>
@endsection