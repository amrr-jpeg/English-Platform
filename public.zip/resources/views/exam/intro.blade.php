@extends('layouts.kids')

@section('content')
<div class="hero">
    <div>
        <h1 class="h1">Экзамены</h1>
        <p class="muted">Экзамены открываются после прохождения каждых 10 уроков.</p>
    </div>
</div>

@if(session('error'))
    <div class="toast toast--bad">{{ session('error') }}</div>
@endif

<div class="grid">
    @foreach($exams as $exam)
        <div class="card">
            <div class="badge">
                Уроки {{ $exam['from'] }}–{{ $exam['to'] }}
            </div>

            <h2 class="h2">{{ $exam['title'] }}</h2>

            <p class="muted">{{ $exam['description'] }}</p>

            <div class="progress">
                <div class="progress__bar" style="width: {{ $exam['total'] > 0 ? ($exam['completed'] / $exam['total']) * 100 : 0 }}%"></div>
            </div>

            <p class="muted small">
                Пройдено уроков: {{ $exam['completed'] }} / {{ $exam['total'] }}
            </p>

            @if($exam['unlocked'])
                <a class="btn" href="{{ route('exam.start', $exam['number']) }}">
    Начать экзамен
</a>
            @else
                <button class="btn btn--disabled" disabled>
                    Заблокировано
                </button>
            @endif
        </div>
    @endforeach
</div>
@endsection