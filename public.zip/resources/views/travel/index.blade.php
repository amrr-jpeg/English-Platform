@extends('layouts.kids')

@section('content')
<div class="travelHero card">
    <div>
        <div class="badge">🌍 Отдельный курс</div>
        <h1 class="h1">Английский для путешествий</h1>
        <p class="muted">
            Изучи самые нужные слова и фразы для аэропорта, отеля, ресторана, такси и экстренных ситуаций.
        </p>
    </div>

    <a class="btn" href="{{ route('travel.games') }}">
        🎮 Игры по путешествиям
    </a>
    <a class="btn" href="{{ route('travel.scenario') }}">
    ✈️ Симулятор путешествия
</a>
</div>

<div class="travelGrid">
    @foreach($lessons as $lesson)
        <div class="card travelLessonCard">
            <div class="badge">
                {{ $lesson->level }}
            </div>

            <h2>{{ $lesson->title }}</h2>
            <p class="muted">{{ $lesson->description }}</p>

            <div class="lessonMeta">
                <span class="pill">🧠 {{ $lesson->exercises_count }} заданий</span>

                @if(in_array($lesson->id, $completedIds))
                    <span class="pill">✅ пройден</span>
                @else
                    <span class="pill">⏳ не пройден</span>
                @endif
            </div>

            <a class="btn" href="{{ route('lessons.show', $lesson) }}">
                Начать урок
            </a>
        </div>
    @endforeach
</div>
@endsection