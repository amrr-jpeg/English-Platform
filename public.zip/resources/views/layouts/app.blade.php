<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'English Play') }}</title>

    <link rel="stylesheet" href="{{ asset('css/kids.css') }}">
</head>
<body>

    {{-- единый фон --}}
    <div class="bg-layer" aria-hidden="true"></div>

    <div class="app">
        <div class="container">

            {{-- навигация (общая для всех страниц) --}}
            @include('layouts.navigation')

            {{-- Header секция (если где-то используется) --}}
            @hasSection('header')
                <header class="page-header card">
                    <div class="page-header__inner">
                        @yield('header')
                    </div>
                </header>
            @endif

            <main class="page-content">
                {{-- Вариант 1: если страница рендерится через Blade-компонент <x-app-layout> --}}
                @isset($slot)
                    {{ $slot }}
                @endisset

                {{-- Вариант 2: если страница через @extends('layouts.app') + @section('content') --}}
                @yield('content')
            </main>

            <footer class="footer">
                <div class="muted small">Сделано на Laravel • Дипломный проект</div>
            </footer>

        </div>
    </div>

    <script>
        // мини-анимация появления карточек 
        window.addEventListener('load', () => {
            document.body.classList.add('page-ready');
            document.querySelectorAll('.card').forEach((el, i) => {
                setTimeout(() => el.classList.add('in'), 60 + i * 40);
            });
        });
    </script>
</body>
</html>
