@php
    $route = Route::currentRouteName();
@endphp

<header class="topbar">
    <a class="brand" href="{{ Route::has('dashboard') ? route('dashboard') : url('/') }}">
        <span class="brand__logo">🎓</span>
        <span class="brand__text">Английский</span>
    </a>

    <button class="burger" id="burgerBtn" type="button">☰</button>

    <div class="navScroller">
        <button class="navScrollBtn" type="button" id="navScrollLeft">‹</button>

        <nav class="mainMenu" id="mainMenu">
            @if(Route::has('dashboard'))
                <a href="{{ route('dashboard') }}"
                   class="mainMenu__link {{ $route === 'dashboard' ? 'active' : '' }}">
                    📚 Уроки
                </a>
            @endif

            @if(Route::has('games.index'))
                <a href="{{ route('games.index') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'games') ? 'active' : '' }}">
                    🎮 Игры
                </a>
            @endif

            @if(Route::has('shop'))
                <a href="{{ route('shop') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'shop') ? 'active' : '' }}">
                    🛒 Магазин
                </a>
            @endif

            @if(Route::has('travel.index'))
                <a href="{{ route('travel.index') }}"
                  class="mainMenu__link {{ str_starts_with($route ?? '', 'travel') ? 'active' : '' }}">
                  🌍 Travel
                </a>
            @endif

            @if(Route::has('achievements'))
                <a href="{{ route('achievements') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'achievements') ? 'active' : '' }}">
                    🏆 Достижения
                </a>
            @endif

            @if(Route::has('stats.index'))
                <a href="{{ route('stats.index') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'stats') ? 'active' : '' }}">
                    📊 Статистика
                </a>
            @endif

            @if(Route::has('exam.intro'))
                <a href="{{ route('exam.intro') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'exam') ? 'active' : '' }}">
                    🧠 Экзамен
                </a>
            @endif

            @if(Route::has('chests.index'))
                <a href="{{ route('chests.index') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'chests') ? 'active' : '' }}">
                    🎁 Сундуки
                </a>
            @endif

            @if(Route::has('mistakes.index'))
                <a href="{{ route('mistakes.index') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'mistakes') ? 'active' : '' }}">
                    ❌ Ошибки
                </a>
            @endif

            @if(Route::has('profile.page'))
                <a href="{{ route('profile.page') }}"
                   class="mainMenu__link {{ str_starts_with($route ?? '', 'profile') ? 'active' : '' }}">
                    👤 Профиль
                </a>
            @endif

            @auth
                @if((auth()->user()->is_admin ?? false) && Route::has('admin.index'))
                    <a href="{{ route('admin.index') }}"
                       class="mainMenu__link mainMenu__link--admin {{ str_starts_with($route ?? '', 'admin') ? 'active' : '' }}">
                        ⚙️ Админка
                    </a>
                @endif
            @endauth
        </nav>

        <button class="navScrollBtn" type="button" id="navScrollRight">›</button>
    </div>

    <div class="userPanel">
        @auth
            <div class="userStats">
                <span>⭐ {{ auth()->user()->level ?? 1 }}</span>
                <span>✨ {{ auth()->user()->xp ?? 0 }}</span>
                <span>🪙 {{ auth()->user()->coins ?? 0 }}</span>
                <span>🔥 {{ auth()->user()->streak ?? 0 }}</span>
            </div>

            <div class="userActions">
                <span class="userName">{{ auth()->user()->name }}</span>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="miniBtn" type="submit">Выйти</button>
                </form>
            </div>
        @endauth

        @guest
            <div class="userActions">
                @if(Route::has('login'))
                    <a class="miniBtn" href="{{ route('login') }}">Вход</a>
                @endif

                @if(Route::has('register'))
                    <a class="miniBtn miniBtn--primary" href="{{ route('register') }}">Регистрация</a>
                @endif
            </div>
        @endguest
    </div>
</header>