@extends('layouts.kids')

@section('content')
<div class="hero">
    <div>
        <h1 class="h1">Работа над ошибками</h1>
        <p class="muted">Здесь собраны задания, в которых ты ошибался.</p>
    </div>

    <div class="card">
        <div class="h2">{{ $mistakes->count() }}</div>
        <div class="muted">ошибок для повторения</div>
    </div>
</div>

<div class="stack">
    @forelse($mistakes as $mistake)
        @php
            $exercise = $mistake->exercise;
        @endphp

        @if($exercise)
            <div class="card mistakeCard">
                <div>
                    <div class="badge">
                        {{ $exercise->lesson->title ?? 'Урок' }}
                    </div>

                    <h2>{{ $exercise->question }}</h2>

                    <p class="muted">
                        Твой ответ:
                        <b>{{ $mistake->user_answer ?: '—' }}</b>
                    </p>

                    <p class="muted">
                        Правильный ответ:
                        <b>{{ $exercise->answer ?: 'см. задание' }}</b>
                    </p>
                </div>

                @if($exercise->lesson)
                    <a class="btn" href="{{ route('lessons.show', $exercise->lesson) }}">
                        Повторить в уроке
                    </a>
                @endif
            </div>
        @endif
    @empty
        <div class="card emptyState">
            <div class="emptyState__icon">✅</div>
            <div class="h2">Ошибок пока нет</div>
            <div class="muted">Отличная работа!</div>
        </div>
    @endforelse
</div>
@endsection