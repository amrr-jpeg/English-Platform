@extends('layouts.kids')

@section('content')
<div class="hero">
    <div>
        <h1 class="h1">Мини-игры</h1>
        <p class="muted">Выбирай игру и уровень сложности. Чем сложнее уровень — тем больше награда.</p>
    </div>

    <div class="card">
        <div class="h2">🎮 5</div>
        <div class="muted">видов игр</div>
    </div>
</div>

<div class="gamesGrid gamesGrid--wide">
    @foreach($games as $game)
        <div class="gameTile gameTile--levels">
            <div class="gameTile__icon">{{ $game['icon'] }}</div>

            <h2>{{ $game['title'] }}</h2>
            <p>{{ $game['description'] }}</p>

            <div class="levelButtons">
                @foreach($levels as $key => $name)
                    <a class="levelBtn levelBtn--{{ $key }}" href="{{ route($game['route'], $key) }}">
                        {{ $name }}
                    </a>
                @endforeach
            </div>
        </div>
    @endforeach
</div>
@endsection