@extends('layouts.kids')

@section('content')
<a class="link" href="{{ route('dashboard') }}">← Назад к урокам</a>

<div class="lessonHeader">
    <div>
        <h1 class="h1">{{ $lesson->title }}</h1>
        <p class="muted">{{ $lesson->description }}</p>
    </div>

    @php
        $total = max(1, $userLesson->total_exercises);
        $percent = intval(($userLesson->completed_exercises / $total) * 100);
    @endphp

    <div class="card progressCard">
        <div class="progressCard__title">Твой прогресс</div>

        <div class="progress">
            <div class="progress__bar" style="width: {{ $percent }}%"></div>
        </div>

        <div class="muted small">
            {{ $userLesson->completed_exercises }} / {{ $userLesson->total_exercises }} ({{ $percent }}%)
        </div>

        @if($userLesson->is_completed)
            <div class="badge badge--ok">Урок пройден ✅</div>
        @endif
    </div>
</div>

<div class="stack">
@foreach($lesson->exercises as $ex)
    @php
        $state = $done->get($ex->id);
        $isCorrect = $state?->is_correct ?? false;

        $data = $ex->data ?? [];
        if (is_string($data)) {
            $data = json_decode($data, true) ?: [];
        }
        if (!is_array($data)) {
            $data = [];
        }
    @endphp

    <div class="card exerciseCard">
        <div class="exercise__head">
            <div class="exercise__q">
                <div class="badge">Задание {{ $ex->order }}</div>
                <div class="exercise__question">{{ $ex->question }}</div>
            </div>

            <div class="rewards">
                <span class="pill">✨ +{{ $ex->xp_reward }}</span>
                <span class="pill">🪙 +{{ $ex->coin_reward }}</span>
            </div>
        </div>

        @if($isCorrect)
            <div class="toast toast--ok">Уже правильно ✅</div>
        @endif

        @if(session('success'))
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            AppSounds.play('correct');
        });
    </script>
@endif

@if(session('error'))
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            AppSounds.play('wrong');
        });
    </script>
@endif

        <form method="POST" action="{{ route('exercises.submit', $ex) }}" class="answerForm">
            @csrf

            @if($ex->type === 'choice')
                @php
                    $options = $ex->options ?? [];

                    if (is_string($options)) {
                        $options = json_decode($options, true) ?: [];
                    }

                    if (!is_array($options)) {
                        $options = [];
                    }
                @endphp

                <div class="choices">
                    @foreach($options as $opt)
                        <label class="choice">
                            <input type="radio" name="answer" value="{{ $opt }}" required>
                            <span>{{ $opt }}</span>
                        </label>
                    @endforeach
                </div>

            @elseif($ex->type === 'input')
                <input class="input" type="text" name="answer" placeholder="Напиши ответ..." required>

            @elseif($ex->type === 'scramble')
                <div class="muted small">Собери слово из букв:</div>
                <div class="letterCloud">
                    @foreach(($data['letters'] ?? []) as $letter)
                        <span>{{ $letter }}</span>
                    @endforeach
                </div>

                <input class="input" type="text" name="answer" placeholder="Впиши слово..." required>

            @elseif($ex->type === 'drag_word')
                @php
                    $letters = $data['letters'] ?? [];
                @endphp

                <div class="muted small">Перетащи буквы в правильном порядке:</div>

                <div class="dragGame" data-drag-game data-join="">
                    <div class="dragZone dragZone--answer" data-drop>
                        <div class="dragZone__title">Ответ</div>
                    </div>

                    <div class="dragZone dragZone--pool" data-pool>
                        <div class="dragZone__title">Буквы</div>

                        @foreach($letters as $letter)
                            <button type="button" class="dragChip" draggable="true" data-value="{{ $letter }}">
                                {{ $letter }}
                            </button>
                        @endforeach
                    </div>

                    <input type="hidden" name="answer" class="dragAnswer" required>

                    <div class="row">
                        <button type="button" class="btn btn--ghost dragReset">Сбросить</button>
                    </div>
                </div>

            @elseif($ex->type === 'drag_sentence')
                @php
                    $words = $data['words'] ?? [];
                @endphp

                <div class="muted small">Перетащи слова и собери предложение:</div>

                <div class="dragGame" data-drag-game data-join=" ">
                    <div class="dragZone dragZone--answer" data-drop>
                        <div class="dragZone__title">Предложение</div>
                    </div>

                    <div class="dragZone dragZone--pool" data-pool>
                        <div class="dragZone__title">Слова</div>

                        @foreach($words as $word)
                            <button type="button" class="dragChip dragChip--word" draggable="true" data-value="{{ $word }}">
                                {{ $word }}
                            </button>
                        @endforeach
                    </div>

                    <input type="hidden" name="answer" class="dragAnswer" required>

                    <div class="row">
                        <button type="button" class="btn btn--ghost dragReset">Сбросить</button>
                    </div>
                </div>

            @elseif($ex->type === 'pairs')
                <div class="muted small">Соедини пары: выбери перевод.</div>

                <div class="pairsList">
                    @foreach(($data['pairs'] ?? []) as $pair)
                        @php $left = $pair['left'] ?? ''; @endphp

                        @if($left !== '')
                            <div class="pairRow">
                                <div class="pairRow__left">{{ $left }}</div>

                                <select class="input" name="pairs[{{ $left }}]" required>
                                    <option value="">— выбрать —</option>

                                    @foreach(($data['right_options'] ?? []) as $opt)
                                        <option value="{{ $opt }}">{{ $opt }}</option>
                                    @endforeach
                                </select>
                            </div>
                        @endif
                    @endforeach
                </div>

                <input type="hidden" name="answer" value="pairs" required>

            @elseif($ex->type === 'syllables')
                @php
                    $syllables = $data['syllables'] ?? [];
                @endphp

                <div class="muted small">Перетащи слоги и собери слово:</div>

                <div class="dragGame" data-drag-game data-join="">
                    <div class="dragZone dragZone--answer" data-drop>
                        <div class="dragZone__title">Собранное слово</div>
                    </div>

                    <div class="dragZone dragZone--pool" data-pool>
                        <div class="dragZone__title">Слоги</div>

                        @foreach($syllables as $s)
                            <button type="button" class="dragChip" draggable="true" data-value="{{ $s }}">
                                {{ $s }}
                            </button>
                        @endforeach
                    </div>

                    <input type="hidden" name="answer" class="dragAnswer" required>

                    <div class="row">
                        <button type="button" class="btn btn--ghost dragReset">Сбросить</button>
                    </div>
                </div>

            @elseif($ex->type === 'flashcards')
                @php
                    $cards = $data['cards'] ?? [];
                @endphp

                <div class="flashcards">
                    @foreach($cards as $card)
                        <button type="button" class="flashcard">
                            <span class="flashcard__inner">
                                <span class="flashcard__side flashcard__front">
                                    {{ $card['front'] ?? '' }}
                                </span>

                                <span class="flashcard__side flashcard__back">
                                    {{ $card['back'] ?? '' }}
                                </span>
                            </span>
                        </button>
                    @endforeach
                </div>

                <input type="hidden" name="answer" value="done">
            @endif

            <button class="btn" type="submit">
                @if($ex->type === 'flashcards')
                    Я запомнил
                @else
                    Проверить
                @endif
            </button>

            @error('answer')
                <div class="toast toast--bad">{{ $message }}</div>
            @enderror
        </form>
    </div>
@endforeach
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-drag-game]').forEach((game) => {
        const drop = game.querySelector('[data-drop]');
        const pool = game.querySelector('[data-pool]');
        const hidden = game.querySelector('.dragAnswer');
        const reset = game.querySelector('.dragReset');
        const joiner = game.dataset.join ?? '';

        if (!drop || !pool || !hidden) {
            return;
        }

        let dragged = null;

        const updateAnswer = () => {
            hidden.value = Array.from(drop.querySelectorAll('.dragChip'))
                .map((chip) => chip.dataset.value || chip.textContent.trim())
                .join(joiner)
                .trim();
        };

        const shufflePool = () => {
            const chips = Array.from(pool.querySelectorAll('.dragChip'));
            chips.sort(() => Math.random() - 0.5).forEach((chip) => pool.appendChild(chip));
        };

        const makeDropZone = (zone) => {
            zone.addEventListener('dragover', (event) => {
                event.preventDefault();
                zone.classList.add('dragZone--active');
            });

            zone.addEventListener('dragleave', () => {
                zone.classList.remove('dragZone--active');
            });

            zone.addEventListener('drop', (event) => {
                event.preventDefault();
                zone.classList.remove('dragZone--active');

                if (dragged) {
                    zone.appendChild(dragged);
                    updateAnswer();
                }
            });
        };

        game.querySelectorAll('.dragChip').forEach((chip) => {
            chip.addEventListener('dragstart', (event) => {
                dragged = chip;
                chip.classList.add('dragChip--dragging');
                event.dataTransfer.effectAllowed = 'move';
            });

            chip.addEventListener('dragend', () => {
                chip.classList.remove('dragChip--dragging');
                dragged = null;
                updateAnswer();
            });

            chip.addEventListener('click', () => {
                if (chip.closest('[data-pool]')) {
                    drop.appendChild(chip);
                } else {
                    pool.appendChild(chip);
                }

                updateAnswer();
            });
        });

        makeDropZone(drop);
        makeDropZone(pool);

        if (reset) {
            reset.addEventListener('click', () => {
                Array.from(drop.querySelectorAll('.dragChip')).forEach((chip) => pool.appendChild(chip));
                shufflePool();
                updateAnswer();
            });
        }

        shufflePool();
        updateAnswer();
    });

    document.querySelectorAll('.flashcard').forEach((card) => {
        card.addEventListener('click', () => {
            card.classList.toggle('flashcard--flipped');
        });
    });
});
</script>
@endsection