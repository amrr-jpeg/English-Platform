@extends('layouts.kids')

@section('content')
<div class="lessonPage">
    <div class="lessonHeader">
        <div class="card">
            <h1 class="h1">Учись английскому играя 🎮</h1>
            <p class="muted">Проходи уроки, получай XP и монеты, прокачивай персонажа.</p>

            <div class="grid statsGrid">
                <div class="card statCard">
                    <div class="muted small">Уровень</div>
                    <div class="statValue">{{ $user->level }}</div>
                </div>

                <div class="card statCard">
                    <div class="muted small">Опыт</div>
                    <div class="statValue">{{ $user->xp }}</div>
                </div>

                <div class="card statCard">
                    <div class="muted small">Монеты</div>
                    <div class="statValue">{{ $user->coins }}</div>
                </div>

                <div class="card statCard">
                    <div class="muted small">Серия дней</div>
                    <div class="statValue">🔥 {{ $user->streak ?? 0 }}</div>
                    <div class="muted small">Рекорд: {{ $user->best_streak ?? 0 }}</div>
                </div>
            </div>

            <div class="muted small" style="margin-top:12px;">
                Подсказка: повышай серию, проходя хотя бы 1 упражнение в день 🔥
            </div>
        </div>

        <div class="exList">
            <div class="card">
                <div class="exercise__head">
                    <div class="badge">🎯 Миссия дня</div>
                    <div class="pill">🔥 Серия: {{ $user->streak ?? 0 }}</div>
                </div>
                <div class="muted" style="margin-top:10px;">
                    Пройди хотя бы 1 упражнение сегодня и сохрани серию!
                </div>
            </div>

            <div class="card">
                <div class="row">
                    <div class="logo" style="font-size:26px;">😊</div>
                    <div>
                        <div style="font-weight:950;">Твой герой</div>
                        <div class="muted small">Чем больше уроков — тем круче!</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="margin-top:18px;">
        <h2 class="h2">Уроки</h2>
        <div class="muted small">Выбирай уроки по порядку и прокачивай героя</div>
    </div>

    <div class="grid" style="margin-top:14px;">
        @foreach ($lessons as $lesson)
            @php
                $p = $progress->get($lesson->id);
                $done = $p?->completed_exercises ?? 0;
                $total = $p?->total_exercises ?? $lesson->exercises()->count();
                $percent = $total > 0 ? intval(($done / $total) * 100) : 0;
                $unlocked = in_array($lesson->id, $unlockedLessonIds);
            @endphp

            <div class="card lessonCard">
                <div class="exercise__head">
                    <div class="badge {{ $percent >= 100 ? 'badge--ok' : '' }}">#{{ $lesson->order }}</div>
                    <div class="muted small">{{ $percent }}%</div>
                </div>

                <div class="lessonCard__title">{{ $lesson->title }}</div>
                <div class="muted small lessonCard__desc">{{ $lesson->description }}</div>

                <div class="progress">
                    <div class="progress__bar" style="width: {{ $percent }}%"></div>
                </div>

                <div class="lessonCard__bottom">
                    <div class="muted small">Прогресс: {{ $done }}/{{ $total }}</div>

                    @if($unlocked)
                        <a class="btn" href="{{ route('lessons.show', $lesson) }}">Начать</a>
                    @else
                        <button class="btn btn--disabled" disabled>Закрыто 🔒</button>
                    @endif
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
