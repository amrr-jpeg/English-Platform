@extends('layouts.kids')

@section('content')
<section class="adminHero card">
    <div>
        <div class="badge">Панель управления</div>
        <h1 class="h1">Админ-панель English Play</h1>
        <p class="muted">Управляй уроками, теорией и упражнениями из одного удобного раздела.</p>
    </div>

    <div class="adminHero__actions">
        <a class="btn" href="{{ route('admin.lessons.create') }}">+ Новый урок</a>
        <a class="btn btn--ghost" href="{{ route('admin.lessons') }}">Все уроки</a>
        <a class="btn btn--ghost" href="{{ route('dashboard') }}">На сайт</a>
    </div>
</section>

<div class="adminGrid">
    <a class="adminTile card" href="{{ route('admin.lessons') }}">
        <div class="adminTile__icon">📚</div>
        <div>
            <h2 class="h2">Конструктор уроков</h2>
            <p class="muted small">Создание урока, теории и всех упражнений на одной странице.</p>
        </div>
    </a>

    <div class="adminTile card">
        <div class="adminTile__icon">🧩</div>
        <div>
            <h2 class="h2">Типы упражнений</h2>
            <p class="muted small">Выбор ответа, ввод, сборка слова, пары и слоги без ручного JSON.</p>
        </div>
    </div>
</div>
@endsection
