@extends('layouts.kids')

@section('content')
<a class="link" href="{{ route('dashboard') }}">← Назад</a>

<div class="shopHero">
    <div>
        <h1 class="h1">Магазин</h1>
        <p class="muted">
            Покупай предметы один раз, выбирай их и украшай персонажа.
        </p>
    </div>

    <div class="card shopWallet">
        <div class="shopWallet__coins">🪙 {{ $user->coins }}</div>
        <div class="muted">твой баланс</div>
    </div>
</div>

@if(session('success'))
    <div class="toast toast--ok">{{ session('success') }}</div>
@endif

@if(session('error'))
    <div class="toast toast--bad">{{ session('error') }}</div>
@endif

@if(session('info'))
    <div class="toast">{{ session('info') }}</div>
@endif

<div class="shopLayout">
    <aside class="card shopPreview">
        <h2 class="h2">Твой образ</h2>

        <div class="shopAvatar buddy--{{ $user->skin ?? 'blue' }}
            {{ $user->profile_background ?? '' }}
            {{ $user->profile_frame ?? '' }}
            {{ $user->equipped_effect ? 'shopAvatar--' . $user->equipped_effect : '' }}">

            @if($user->equipped_hat)
                <div class="shopAvatar__hat">
                    @if($user->equipped_hat === 'hat_crown')
                        👑
                    @elseif($user->equipped_hat === 'hat_cap')
                        🧢
                    @elseif($user->equipped_hat === 'hat_grad')
                        🎓
                    @endif
                </div>
            @endif

            <div class="shopAvatar__face">
                @if(($user->skin ?? 'blue') === 'pink')
                    😊
                @elseif(($user->skin ?? 'blue') === 'green')
                    😎
                @else
                    😄
                @endif
            </div>

            @if($user->equipped_accessory)
                <div class="shopAvatar__accessory">
                    @if($user->equipped_accessory === 'acc_glasses')
                        😎
                    @elseif($user->equipped_accessory === 'acc_star')
                        ⭐
                    @elseif($user->equipped_accessory === 'acc_fire')
                        🔥
                    @endif
                </div>
            @endif
        </div>

        <div class="shopEquippedList">
            <div>
                <b>Головной убор:</b>
                {{ $user->equipped_hat ?: 'не выбран' }}
            </div>

            <div>
                <b>Аксессуар:</b>
                {{ $user->equipped_accessory ?: 'не выбран' }}
            </div>

            <div>
                <b>Эффект:</b>
                {{ $user->equipped_effect ?: 'не выбран' }}
            </div>

            <div>
                <b>Фон:</b>
                {{ $user->profile_background ?: 'не выбран' }}
            </div>

            <div>
                <b>Рамка:</b>
                {{ $user->profile_frame ?: 'не выбрана' }}
            </div>
        </div>
    </aside>

    <main class="shopContent">
        @foreach($items as $type => $group)
            <section class="shopSection">
                <div class="shopSection__head">
                    <h2 class="h2">
                        @if($type === 'hat')
                            🎩 Головные уборы
                        @elseif($type === 'accessory')
                            ⭐ Аксессуары
                        @elseif($type === 'effect')
                            ✨ Эффекты
                        @elseif($type === 'background')
                            🌄 Фоны профиля
                        @elseif($type === 'frame')
                            🖼️ Рамки
                        @else
                            🛍️ Предметы
                        @endif
                    </h2>
                </div>

                <div class="shopGrid">
                    @foreach($group as $item)
                        @php
                            $isOwned = in_array($item['key'], $owned);

                            $isEquipped =
                                ($type === 'hat' && $user->equipped_hat === $item['key']) ||
                                ($type === 'accessory' && $user->equipped_accessory === $item['key']) ||
                                ($type === 'effect' && $user->equipped_effect === $item['key']) ||
                                ($type === 'background' && $user->profile_background === $item['key']) ||
                                ($type === 'frame' && $user->profile_frame === $item['key']);
                        @endphp

                        <div class="shopItem {{ $isEquipped ? 'shopItem--equipped' : '' }}">
                            <div class="shopItem__icon">
                                {{ $item['icon'] }}
                            </div>

                            <div class="shopItem__body">
                                <h3>{{ $item['name'] }}</h3>

                                <p>{{ $item['description'] }}</p>

                                <div class="shopItem__meta">
                                    @if($isEquipped)
                                        <span class="badge badge--ok">Выбрано</span>
                                    @elseif($isOwned)
                                        <span class="badge">Куплено</span>
                                    @else
                                        <span class="badge">Цена: {{ $item['price'] }} 🪙</span>
                                    @endif
                                </div>
                            </div>

                            <div class="shopItem__actions">
                                @if(!$isOwned)
                                    <form method="POST" action="{{ route('shop.buy') }}">
                                        @csrf

                                        <input type="hidden" name="item_key" value="{{ $item['key'] }}">

                                        <button class="btn" type="submit">
                                            Купить
                                        </button>
                                    </form>
                                @else
                                    <form method="POST" action="{{ route('shop.equip') }}">
                                        @csrf

                                        <input type="hidden" name="item_key" value="{{ $item['key'] }}">

                                        <button class="btn {{ $isEquipped ? 'btn--ghost' : '' }}" type="submit">
                                            {{ $isEquipped ? 'Снять' : 'Выбрать' }}
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
            </section>
        @endforeach
    </main>
</div>
@endsection