@extends('layouts.kids')

@section('content')
<div class="profileHero card {{ $user->profile_background ?? '' }} {{ $user->profile_frame ?? '' }}">
    <div class="profileAvatar buddy--{{ $user->skin ?? 'blue' }} {{ $user->equipped_effect ? 'shopAvatar--' . $user->equipped_effect : '' }}">
        @if($user->equipped_hat)
            <div class="shopAvatar__hat">
                @if($user->equipped_hat === 'hat_crown') 👑
                @elseif($user->equipped_hat === 'hat_cap') 🧢
                @elseif($user->equipped_hat === 'hat_grad') 🎓
                @endif
            </div>
        @endif

        <div class="shopAvatar__face">
            @if(($user->skin ?? 'blue') === 'pink')
                😊
            @elseif(($user->skin ?? 'blue') === 'green')
                😎
            @else
                😄
            @endif
        </div>

        @if($user->equipped_accessory)
            <div class="shopAvatar__accessory">
                @if($user->equipped_accessory === 'acc_glasses') 😎
                @elseif($user->equipped_accessory === 'acc_star') ⭐
                @elseif($user->equipped_accessory === 'acc_fire') 🔥
                @endif
            </div>
        @endif
    </div>

    <div>
        <h1 class="h1">{{ $user->name }}</h1>
        <p class="muted">{{ $user->email }}</p>

        <div class="profileStatsLine">
            <span>LVL {{ $user->level }}</span>
            <span>✨ {{ $user->xp }} XP</span>
            <span>🪙 {{ $user->coins }}</span>
            <span>🔥 {{ $user->streak }}</span>
        </div>
    </div>
</div>

<div class="statsGrid" style="margin-top:18px;">
    <div class="statCard">
        <div class="statCard__icon">📚</div>
        <div class="statCard__value">{{ $completedLessons }}</div>
        <div class="statCard__label">уроков пройдено</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">🎯</div>
        <div class="statCard__value">{{ $accuracy }}%</div>
        <div class="statCard__label">точность</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">✅</div>
        <div class="statCard__value">{{ $correctAnswers }}</div>
        <div class="statCard__label">правильных ответов</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">🧩</div>
        <div class="statCard__value">{{ $totalAnswers }}</div>
        <div class="statCard__label">ответов всего</div>
    </div>
</div>

<div class="profileGrid">
    <div class="card">
        <h2 class="h2">Последние достижения</h2>

        <div class="profileBadges">
            @forelse($achievements as $achievement)
                <div class="profileBadge">
                    <div>{{ $achievement->icon }}</div>
                    <b>{{ $achievement->title }}</b>
                </div>
            @empty
                <p class="muted">Достижений пока нет.</p>
            @endforelse
        </div>
    </div>

    <div class="card">
        <h2 class="h2">Последние сундуки</h2>

        <div class="stack">
            @forelse($lastChests as $chest)
                <div class="rewardHistoryItem">
                    <div>{{ $chest->reward_label }}</div>
                    <span class="muted small">{{ $chest->created_at->format('d.m.Y H:i') }}</span>
                </div>
            @empty
                <p class="muted">Сундуки пока не открывались.</p>
            @endforelse
        </div>
    </div>
</div>
@endsection