document.addEventListener('DOMContentLoaded', () => {
    const clickableElements = document.querySelectorAll(
        '.btn, .miniBtn, .mainMenu__link, .skinCard, .choice'
    );

    clickableElements.forEach((element) => {
        element.addEventListener('click', () => {
            element.classList.remove('click-pop');
            void element.offsetWidth;
            element.classList.add('click-pop');
        });
    });

    const successToast = document.querySelector('.toast--ok');

    if (successToast) {
        createFloatingText('✨ + успех', window.innerWidth / 2, 110);
    }

    const achievementToast = document.querySelector('.achievementToast');

    if (achievementToast) {
        createConfetti();
        createFloatingText('🏆 достижение!', window.innerWidth / 2, 120);

        setTimeout(() => {
            achievementToast.style.opacity = '0';
            achievementToast.style.transform = 'translateY(20px) scale(0.96)';
        }, 4500);

        setTimeout(() => {
            achievementToast.remove();
        }, 5200);
    }

    const skinCards = document.querySelectorAll('.skinCard');

    skinCards.forEach((card) => {
        card.addEventListener('mousemove', (event) => {
            const rect = card.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            const rotateX = ((y / rect.height) - 0.5) * -8;
            const rotateY = ((x / rect.width) - 0.5) * 8;

            card.style.transform = `translateY(-5px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
        });
    });

    const rewardButtons = document.querySelectorAll('.btn');

    rewardButtons.forEach((button) => {
        button.addEventListener('click', (event) => {
            const text = button.textContent.toLowerCase();

            if (
                text.includes('купить') ||
                text.includes('выбрать') ||
                text.includes('ответить') ||
                text.includes('завершить')
            ) {
                createFloatingText('✨', event.clientX, event.clientY);
            }
        });
    });
});

function createFloatingText(text, x, y) {
    const item = document.createElement('div');
    item.className = 'coin-fly';
    item.textContent = text;
    item.style.left = `${x}px`;
    item.style.top = `${y}px`;

    document.body.appendChild(item);

    setTimeout(() => {
        item.remove();
    }, 950);
}

function createConfetti() {
    const emojis = ['🏆', '✨', '⭐', '🎉', '🪙'];

    for (let i = 0; i < 22; i++) {
        const item = document.createElement('div');
        item.className = 'confetti-item';
        item.textContent = emojis[Math.floor(Math.random() * emojis.length)];

        item.style.left = `${Math.random() * 100}%`;
        item.style.animationDelay = `${Math.random() * 0.35}s`;
        item.style.animationDuration = `${1.5 + Math.random() * 1.2}s`;

        document.body.appendChild(item);

        setTimeout(() => {
            item.remove();
        }, 3000);
    }
}