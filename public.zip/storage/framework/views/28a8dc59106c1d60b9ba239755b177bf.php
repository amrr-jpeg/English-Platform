

<?php $__env->startSection('content'); ?>
<a class="link" href="<?php echo e(route('dashboard')); ?>">← Назад</a>

<div class="shopHero">
    <div>
        <h1 class="h1">Магазин</h1>
        <p class="muted">
            Покупай предметы один раз, выбирай их и украшай персонажа.
        </p>
    </div>

    <div class="card shopWallet">
        <div class="shopWallet__coins">🪙 <?php echo e($user->coins); ?></div>
        <div class="muted">твой баланс</div>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="toast toast--ok"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="toast toast--bad"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<?php if(session('info')): ?>
    <div class="toast"><?php echo e(session('info')); ?></div>
<?php endif; ?>

<div class="shopLayout">
    <aside class="card shopPreview">
        <h2 class="h2">Твой образ</h2>

        <div class="shopAvatar buddy--<?php echo e($user->skin ?? 'blue'); ?>

            <?php echo e($user->profile_background ?? ''); ?>

            <?php echo e($user->profile_frame ?? ''); ?>

            <?php echo e($user->equipped_effect ? 'shopAvatar--' . $user->equipped_effect : ''); ?>">

            <?php if($user->equipped_hat): ?>
                <div class="shopAvatar__hat">
                    <?php if($user->equipped_hat === 'hat_crown'): ?>
                        👑
                    <?php elseif($user->equipped_hat === 'hat_cap'): ?>
                        🧢
                    <?php elseif($user->equipped_hat === 'hat_grad'): ?>
                        🎓
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="shopAvatar__face">
                <?php if(($user->skin ?? 'blue') === 'pink'): ?>
                    😊
                <?php elseif(($user->skin ?? 'blue') === 'green'): ?>
                    😎
                <?php else: ?>
                    😄
                <?php endif; ?>
            </div>

            <?php if($user->equipped_accessory): ?>
                <div class="shopAvatar__accessory">
                    <?php if($user->equipped_accessory === 'acc_glasses'): ?>
                        😎
                    <?php elseif($user->equipped_accessory === 'acc_star'): ?>
                        ⭐
                    <?php elseif($user->equipped_accessory === 'acc_fire'): ?>
                        🔥
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="shopEquippedList">
            <div>
                <b>Головной убор:</b>
                <?php echo e($user->equipped_hat ?: 'не выбран'); ?>

            </div>

            <div>
                <b>Аксессуар:</b>
                <?php echo e($user->equipped_accessory ?: 'не выбран'); ?>

            </div>

            <div>
                <b>Эффект:</b>
                <?php echo e($user->equipped_effect ?: 'не выбран'); ?>

            </div>

            <div>
                <b>Фон:</b>
                <?php echo e($user->profile_background ?: 'не выбран'); ?>

            </div>

            <div>
                <b>Рамка:</b>
                <?php echo e($user->profile_frame ?: 'не выбрана'); ?>

            </div>
        </div>
    </aside>

    <main class="shopContent">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="shopSection">
                <div class="shopSection__head">
                    <h2 class="h2">
                        <?php if($type === 'hat'): ?>
                            🎩 Головные уборы
                        <?php elseif($type === 'accessory'): ?>
                            ⭐ Аксессуары
                        <?php elseif($type === 'effect'): ?>
                            ✨ Эффекты
                        <?php elseif($type === 'background'): ?>
                            🌄 Фоны профиля
                        <?php elseif($type === 'frame'): ?>
                            🖼️ Рамки
                        <?php else: ?>
                            🛍️ Предметы
                        <?php endif; ?>
                    </h2>
                </div>

                <div class="shopGrid">
                    <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isOwned = in_array($item['key'], $owned);

                            $isEquipped =
                                ($type === 'hat' && $user->equipped_hat === $item['key']) ||
                                ($type === 'accessory' && $user->equipped_accessory === $item['key']) ||
                                ($type === 'effect' && $user->equipped_effect === $item['key']) ||
                                ($type === 'background' && $user->profile_background === $item['key']) ||
                                ($type === 'frame' && $user->profile_frame === $item['key']);
                        ?>

                        <div class="shopItem <?php echo e($isEquipped ? 'shopItem--equipped' : ''); ?>">
                            <div class="shopItem__icon">
                                <?php echo e($item['icon']); ?>

                            </div>

                            <div class="shopItem__body">
                                <h3><?php echo e($item['name']); ?></h3>

                                <p><?php echo e($item['description']); ?></p>

                                <div class="shopItem__meta">
                                    <?php if($isEquipped): ?>
                                        <span class="badge badge--ok">Выбрано</span>
                                    <?php elseif($isOwned): ?>
                                        <span class="badge">Куплено</span>
                                    <?php else: ?>
                                        <span class="badge">Цена: <?php echo e($item['price']); ?> 🪙</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="shopItem__actions">
                                <?php if(!$isOwned): ?>
                                    <form method="POST" action="<?php echo e(route('shop.buy')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="item_key" value="<?php echo e($item['key']); ?>">

                                        <button class="btn" type="submit">
                                            Купить
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('shop.equip')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="item_key" value="<?php echo e($item['key']); ?>">

                                        <button class="btn <?php echo e($isEquipped ? 'btn--ghost' : ''); ?>" type="submit">
                                            <?php echo e($isEquipped ? 'Снять' : 'Выбрать'); ?>

                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/shop.blade.php ENDPATH**/ ?>