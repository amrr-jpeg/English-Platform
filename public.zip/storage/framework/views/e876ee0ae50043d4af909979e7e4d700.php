<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Английский в игре</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/kids.css')); ?>">
</head>

<body class="theme-skin-<?php echo e(auth()->check() ? (auth()->user()->skin ?? 'blue') : 'blue'); ?>">
    <div class="bg-layer"></div>

    <div class="container">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="footer">
            Сделано на Laravel • Дипломный проект
        </footer>
    </div>

    <?php if(session('achievement_unlocked')): ?>
        <div class="achievementToast">
            <div class="achievementToast__icon">
                <?php echo e(session('achievement_unlocked.icon')); ?>

            </div>

            <div>
                <div class="achievementToast__title">
                    Достижение открыто: <?php echo e(session('achievement_unlocked.title')); ?>

                </div>

                <div class="achievementToast__text">
                    <?php echo e(session('achievement_unlocked.description')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <script src="<?php echo e(asset('js/kids-ui.js')); ?>"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const burgerBtn = document.getElementById('burgerBtn');
    const mainMenu = document.getElementById('mainMenu');
    const navLeft = document.getElementById('navScrollLeft');
    const navRight = document.getElementById('navScrollRight');

    if (burgerBtn && mainMenu) {
        burgerBtn.onclick = function (e) {
            e.preventDefault();
            mainMenu.classList.toggle('open');
            burgerBtn.classList.toggle('active');
        };
    }

    if (navLeft && mainMenu) {
        navLeft.onclick = function () {
            mainMenu.scrollBy({
                left: -260,
                behavior: 'smooth'
            });
        };
    }

    if (navRight && mainMenu) {
        navRight.onclick = function () {
            mainMenu.scrollBy({
                left: 260,
                behavior: 'smooth'
            });
        };
    }
});
</script>
<script src="<?php echo e(asset('js/sounds.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OSPanel\english-platform\resources\views/layouts/kids.blade.php ENDPATH**/ ?>