

<?php $__env->startSection('content'); ?>
<a class="link" href="<?php echo e(route('travel.index')); ?>">← Назад</a>

<div class="card">
    <h1 class="h1">✈️ Симулятор путешествия</h1>
    <p class="muted">Выбирай правильные фразы в реальных ситуациях.</p>
</div>

<div class="card" id="scenarioBox">

    <div class="badge" id="stepBadge">Сцена 1</div>

    <h2 id="scenarioText"></h2>

    <div class="gameOptions" id="scenarioOptions"></div>

    <div class="gameResult" id="scenarioResult"></div>

</div>

<script>
const scenes = [
    {
        text: "Ты в аэропорту. Где спросить про посадку?",
        correct: "Where is my gate?",
        options: [
            "Where is my gate?",
            "I want sleep",
            "Give me bag"
        ]
    },
    {
        text: "Ты в отеле. Нужно заселиться.",
        correct: "I have a reservation",
        options: [
            "I have a reservation",
            "Give me food",
            "I am room"
        ]
    },
    {
        text: "Ты в ресторане. Хочешь заказать воду.",
        correct: "Can I have water?",
        options: [
            "Can I have water?",
            "I am water",
            "Water go me"
        ]
    }
];

let index = 0;
let score = 0;

const textEl = document.getElementById('scenarioText');
const optionsEl = document.getElementById('scenarioOptions');
const resultEl = document.getElementById('scenarioResult');
const badge = document.getElementById('stepBadge');

function renderScene() {
    if (index >= scenes.length) {
        finish();
        return;
    }

    const scene = scenes[index];

    badge.textContent = "Сцена " + (index + 1);
    textEl.textContent = scene.text;
    optionsEl.innerHTML = '';
    resultEl.textContent = '';

    scene.options.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = 'gameOptionBtn';
        btn.textContent = opt;

        btn.onclick = () => {
            if (opt === scene.correct) {
                score++;
                resultEl.className = 'gameResult gameResult--ok';
                resultEl.textContent = "Правильно 👍";

                if (window.AppSounds) AppSounds.play('correct');
            } else {
                resultEl.className = 'gameResult gameResult--bad';
                resultEl.textContent = "Ошибка 😅";

                if (window.AppSounds) AppSounds.play('wrong');
            }

            index++;
            setTimeout(renderScene, 900);
        };

        optionsEl.appendChild(btn);
    });
}

function finish() {
    textEl.textContent = "Путешествие завершено ✈️";
    optionsEl.innerHTML = '';
    resultEl.className = 'gameResult gameResult--ok';
    resultEl.textContent = "Твой результат: " + score + " / " + scenes.length;

    if (window.AppSounds) AppSounds.play('finish');
}

renderScene();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/travel/scenario.blade.php ENDPATH**/ ?>