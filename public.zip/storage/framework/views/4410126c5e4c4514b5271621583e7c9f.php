<?php
    $route = Route::currentRouteName();
?>

<header class="topbar">
    <a class="brand" href="<?php echo e(Route::has('dashboard') ? route('dashboard') : url('/')); ?>">
        <span class="brand__logo">🎓</span>
        <span class="brand__text">Английский</span>
    </a>

    <button class="burger" id="burgerBtn" type="button">☰</button>

    <div class="navScroller">
        <button class="navScrollBtn" type="button" id="navScrollLeft">‹</button>

        <nav class="mainMenu" id="mainMenu">
            <?php if(Route::has('dashboard')): ?>
                <a href="<?php echo e(route('dashboard')); ?>"
                   class="mainMenu__link <?php echo e($route === 'dashboard' ? 'active' : ''); ?>">
                    📚 Уроки
                </a>
            <?php endif; ?>

            <?php if(Route::has('games.index')): ?>
                <a href="<?php echo e(route('games.index')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'games') ? 'active' : ''); ?>">
                    🎮 Игры
                </a>
            <?php endif; ?>

            <?php if(Route::has('shop')): ?>
                <a href="<?php echo e(route('shop')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'shop') ? 'active' : ''); ?>">
                    🛒 Магазин
                </a>
            <?php endif; ?>

            <?php if(Route::has('travel.index')): ?>
                <a href="<?php echo e(route('travel.index')); ?>"
                  class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'travel') ? 'active' : ''); ?>">
                  🌍 Travel
                </a>
            <?php endif; ?>

            <?php if(Route::has('achievements')): ?>
                <a href="<?php echo e(route('achievements')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'achievements') ? 'active' : ''); ?>">
                    🏆 Достижения
                </a>
            <?php endif; ?>

            <?php if(Route::has('stats.index')): ?>
                <a href="<?php echo e(route('stats.index')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'stats') ? 'active' : ''); ?>">
                    📊 Статистика
                </a>
            <?php endif; ?>

            <?php if(Route::has('exam.intro')): ?>
                <a href="<?php echo e(route('exam.intro')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'exam') ? 'active' : ''); ?>">
                    🧠 Экзамен
                </a>
            <?php endif; ?>

            <?php if(Route::has('chests.index')): ?>
                <a href="<?php echo e(route('chests.index')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'chests') ? 'active' : ''); ?>">
                    🎁 Сундуки
                </a>
            <?php endif; ?>

            <?php if(Route::has('mistakes.index')): ?>
                <a href="<?php echo e(route('mistakes.index')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'mistakes') ? 'active' : ''); ?>">
                    ❌ Ошибки
                </a>
            <?php endif; ?>

            <?php if(Route::has('profile.page')): ?>
                <a href="<?php echo e(route('profile.page')); ?>"
                   class="mainMenu__link <?php echo e(str_starts_with($route ?? '', 'profile') ? 'active' : ''); ?>">
                    👤 Профиль
                </a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <?php if((auth()->user()->is_admin ?? false) && Route::has('admin.index')): ?>
                    <a href="<?php echo e(route('admin.index')); ?>"
                       class="mainMenu__link mainMenu__link--admin <?php echo e(str_starts_with($route ?? '', 'admin') ? 'active' : ''); ?>">
                        ⚙️ Админка
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </nav>

        <button class="navScrollBtn" type="button" id="navScrollRight">›</button>
    </div>

    <div class="userPanel">
        <?php if(auth()->guard()->check()): ?>
            <div class="userStats">
                <span>⭐ <?php echo e(auth()->user()->level ?? 1); ?></span>
                <span>✨ <?php echo e(auth()->user()->xp ?? 0); ?></span>
                <span>🪙 <?php echo e(auth()->user()->coins ?? 0); ?></span>
                <span>🔥 <?php echo e(auth()->user()->streak ?? 0); ?></span>
            </div>

            <div class="userActions">
                <span class="userName"><?php echo e(auth()->user()->name); ?></span>

                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="miniBtn" type="submit">Выйти</button>
                </form>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <div class="userActions">
                <?php if(Route::has('login')): ?>
                    <a class="miniBtn" href="<?php echo e(route('login')); ?>">Вход</a>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <a class="miniBtn miniBtn--primary" href="<?php echo e(route('register')); ?>">Регистрация</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</header><?php /**PATH C:\OSPanel\english-platform\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>