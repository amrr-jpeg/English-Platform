<?php $__env->startSection('content'); ?>
<div class="hero">
    <div>
        <h1 class="h1">Английский В Игре 🎓</h1>
        <p class="muted">Учись английскому в игровом формате: уроки, задания, монеты и прокачка персонажа.</p>

        <?php if(auth()->guard()->check()): ?>
            <a class="btn" href="<?php echo e(route('dashboard')); ?>">Перейти в уроки</a>
        <?php else: ?>
            <div class="row">
                <a class="btn" href="<?php echo e(route('login')); ?>">Войти</a>
                <a class="btn btn--ghost" href="<?php echo e(route('register')); ?>">Регистрация</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="buddy buddy--blue">
        <div class="buddy__face">👋</div>
        <div class="buddy__name">Привет!</div>
        <div class="buddy__mini">Давай начнём 🙂</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/welcome.blade.php ENDPATH**/ ?>