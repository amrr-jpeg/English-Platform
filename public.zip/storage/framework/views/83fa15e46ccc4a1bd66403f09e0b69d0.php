

<?php $__env->startSection('content'); ?>
<div class="profileHero card <?php echo e($user->profile_background ?? ''); ?> <?php echo e($user->profile_frame ?? ''); ?>">
    <div class="profileAvatar buddy--<?php echo e($user->skin ?? 'blue'); ?> <?php echo e($user->equipped_effect ? 'shopAvatar--' . $user->equipped_effect : ''); ?>">
        <?php if($user->equipped_hat): ?>
            <div class="shopAvatar__hat">
                <?php if($user->equipped_hat === 'hat_crown'): ?> 👑
                <?php elseif($user->equipped_hat === 'hat_cap'): ?> 🧢
                <?php elseif($user->equipped_hat === 'hat_grad'): ?> 🎓
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="shopAvatar__face">
            <?php if(($user->skin ?? 'blue') === 'pink'): ?>
                😊
            <?php elseif(($user->skin ?? 'blue') === 'green'): ?>
                😎
            <?php else: ?>
                😄
            <?php endif; ?>
        </div>

        <?php if($user->equipped_accessory): ?>
            <div class="shopAvatar__accessory">
                <?php if($user->equipped_accessory === 'acc_glasses'): ?> 😎
                <?php elseif($user->equipped_accessory === 'acc_star'): ?> ⭐
                <?php elseif($user->equipped_accessory === 'acc_fire'): ?> 🔥
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div>
        <h1 class="h1"><?php echo e($user->name); ?></h1>
        <p class="muted"><?php echo e($user->email); ?></p>

        <div class="profileStatsLine">
            <span>LVL <?php echo e($user->level); ?></span>
            <span>✨ <?php echo e($user->xp); ?> XP</span>
            <span>🪙 <?php echo e($user->coins); ?></span>
            <span>🔥 <?php echo e($user->streak); ?></span>
        </div>
    </div>
</div>

<div class="statsGrid" style="margin-top:18px;">
    <div class="statCard">
        <div class="statCard__icon">📚</div>
        <div class="statCard__value"><?php echo e($completedLessons); ?></div>
        <div class="statCard__label">уроков пройдено</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">🎯</div>
        <div class="statCard__value"><?php echo e($accuracy); ?>%</div>
        <div class="statCard__label">точность</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">✅</div>
        <div class="statCard__value"><?php echo e($correctAnswers); ?></div>
        <div class="statCard__label">правильных ответов</div>
    </div>

    <div class="statCard">
        <div class="statCard__icon">🧩</div>
        <div class="statCard__value"><?php echo e($totalAnswers); ?></div>
        <div class="statCard__label">ответов всего</div>
    </div>
</div>

<div class="profileGrid">
    <div class="card">
        <h2 class="h2">Последние достижения</h2>

        <div class="profileBadges">
            <?php $__empty_1 = true; $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="profileBadge">
                    <div><?php echo e($achievement->icon); ?></div>
                    <b><?php echo e($achievement->title); ?></b>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Достижений пока нет.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <h2 class="h2">Последние сундуки</h2>

        <div class="stack">
            <?php $__empty_1 = true; $__currentLoopData = $lastChests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="rewardHistoryItem">
                    <div><?php echo e($chest->reward_label); ?></div>
                    <span class="muted small"><?php echo e($chest->created_at->format('d.m.Y H:i')); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Сундуки пока не открывались.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/profile-page/index.blade.php ENDPATH**/ ?>