

<?php $__env->startSection('content'); ?>
<a class="link" href="<?php echo e(route('dashboard')); ?>">← Назад к урокам</a>

<div class="lessonHeader">
    <div>
        <h1 class="h1"><?php echo e($lesson->title); ?></h1>
        <p class="muted"><?php echo e($lesson->description); ?></p>
    </div>

    <?php
        $total = max(1, $userLesson->total_exercises);
        $percent = intval(($userLesson->completed_exercises / $total) * 100);
    ?>

    <div class="card progressCard">
        <div class="progressCard__title">Твой прогресс</div>

        <div class="progress">
            <div class="progress__bar" style="width: <?php echo e($percent); ?>%"></div>
        </div>

        <div class="muted small">
            <?php echo e($userLesson->completed_exercises); ?> / <?php echo e($userLesson->total_exercises); ?> (<?php echo e($percent); ?>%)
        </div>

        <?php if($userLesson->is_completed): ?>
            <div class="badge badge--ok">Урок пройден ✅</div>
        <?php endif; ?>
    </div>
</div>

<div class="stack">
<?php $__currentLoopData = $lesson->exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $state = $done->get($ex->id);
        $isCorrect = $state?->is_correct ?? false;

        $data = $ex->data ?? [];
        if (is_string($data)) {
            $data = json_decode($data, true) ?: [];
        }
        if (!is_array($data)) {
            $data = [];
        }
    ?>

    <div class="card exerciseCard">
        <div class="exercise__head">
            <div class="exercise__q">
                <div class="badge">Задание <?php echo e($ex->order); ?></div>
                <div class="exercise__question"><?php echo e($ex->question); ?></div>
            </div>

            <div class="rewards">
                <span class="pill">✨ +<?php echo e($ex->xp_reward); ?></span>
                <span class="pill">🪙 +<?php echo e($ex->coin_reward); ?></span>
            </div>
        </div>

        <?php if($isCorrect): ?>
            <div class="toast toast--ok">Уже правильно ✅</div>
        <?php endif; ?>

        <?php if(session('success')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            AppSounds.play('correct');
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            AppSounds.play('wrong');
        });
    </script>
<?php endif; ?>

        <form method="POST" action="<?php echo e(route('exercises.submit', $ex)); ?>" class="answerForm">
            <?php echo csrf_field(); ?>

            <?php if($ex->type === 'choice'): ?>
                <?php
                    $options = $ex->options ?? [];

                    if (is_string($options)) {
                        $options = json_decode($options, true) ?: [];
                    }

                    if (!is_array($options)) {
                        $options = [];
                    }
                ?>

                <div class="choices">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="choice">
                            <input type="radio" name="answer" value="<?php echo e($opt); ?>" required>
                            <span><?php echo e($opt); ?></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php elseif($ex->type === 'input'): ?>
                <input class="input" type="text" name="answer" placeholder="Напиши ответ..." required>

            <?php elseif($ex->type === 'scramble'): ?>
                <div class="muted small">Собери слово из букв:</div>
                <div class="letterCloud">
                    <?php $__currentLoopData = ($data['letters'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($letter); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <input class="input" type="text" name="answer" placeholder="Впиши слово..." required>

            <?php elseif($ex->type === 'drag_word'): ?>
                <?php
                    $letters = $data['letters'] ?? [];
                ?>

                <div class="muted small">Перетащи буквы в правильном порядке:</div>

                <div class="dragGame" data-drag-game data-join="">
                    <div class="dragZone dragZone--answer" data-drop>
                        <div class="dragZone__title">Ответ</div>
                    </div>

                    <div class="dragZone dragZone--pool" data-pool>
                        <div class="dragZone__title">Буквы</div>

                        <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="dragChip" draggable="true" data-value="<?php echo e($letter); ?>">
                                <?php echo e($letter); ?>

                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <input type="hidden" name="answer" class="dragAnswer" required>

                    <div class="row">
                        <button type="button" class="btn btn--ghost dragReset">Сбросить</button>
                    </div>
                </div>

            <?php elseif($ex->type === 'drag_sentence'): ?>
                <?php
                    $words = $data['words'] ?? [];
                ?>

                <div class="muted small">Перетащи слова и собери предложение:</div>

                <div class="dragGame" data-drag-game data-join=" ">
                    <div class="dragZone dragZone--answer" data-drop>
                        <div class="dragZone__title">Предложение</div>
                    </div>

                    <div class="dragZone dragZone--pool" data-pool>
                        <div class="dragZone__title">Слова</div>

                        <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="dragChip dragChip--word" draggable="true" data-value="<?php echo e($word); ?>">
                                <?php echo e($word); ?>

                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <input type="hidden" name="answer" class="dragAnswer" required>

                    <div class="row">
                        <button type="button" class="btn btn--ghost dragReset">Сбросить</button>
                    </div>
                </div>

            <?php elseif($ex->type === 'pairs'): ?>
                <div class="muted small">Соедини пары: выбери перевод.</div>

                <div class="pairsList">
                    <?php $__currentLoopData = ($data['pairs'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $left = $pair['left'] ?? ''; ?>

                        <?php if($left !== ''): ?>
                            <div class="pairRow">
                                <div class="pairRow__left"><?php echo e($left); ?></div>

                                <select class="input" name="pairs[<?php echo e($left); ?>]" required>
                                    <option value="">— выбрать —</option>

                                    <?php $__currentLoopData = ($data['right_options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($opt); ?>"><?php echo e($opt); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <input type="hidden" name="answer" value="pairs" required>

            <?php elseif($ex->type === 'syllables'): ?>
                <?php
                    $syllables = $data['syllables'] ?? [];
                ?>

                <div class="muted small">Перетащи слоги и собери слово:</div>

                <div class="dragGame" data-drag-game data-join="">
                    <div class="dragZone dragZone--answer" data-drop>
                        <div class="dragZone__title">Собранное слово</div>
                    </div>

                    <div class="dragZone dragZone--pool" data-pool>
                        <div class="dragZone__title">Слоги</div>

                        <?php $__currentLoopData = $syllables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="dragChip" draggable="true" data-value="<?php echo e($s); ?>">
                                <?php echo e($s); ?>

                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <input type="hidden" name="answer" class="dragAnswer" required>

                    <div class="row">
                        <button type="button" class="btn btn--ghost dragReset">Сбросить</button>
                    </div>
                </div>

            <?php elseif($ex->type === 'flashcards'): ?>
                <?php
                    $cards = $data['cards'] ?? [];
                ?>

                <div class="flashcards">
                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="flashcard">
                            <span class="flashcard__inner">
                                <span class="flashcard__side flashcard__front">
                                    <?php echo e($card['front'] ?? ''); ?>

                                </span>

                                <span class="flashcard__side flashcard__back">
                                    <?php echo e($card['back'] ?? ''); ?>

                                </span>
                            </span>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <input type="hidden" name="answer" value="done">
            <?php endif; ?>

            <button class="btn" type="submit">
                <?php if($ex->type === 'flashcards'): ?>
                    Я запомнил
                <?php else: ?>
                    Проверить
                <?php endif; ?>
            </button>

            <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="toast toast--bad"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-drag-game]').forEach((game) => {
        const drop = game.querySelector('[data-drop]');
        const pool = game.querySelector('[data-pool]');
        const hidden = game.querySelector('.dragAnswer');
        const reset = game.querySelector('.dragReset');
        const joiner = game.dataset.join ?? '';

        if (!drop || !pool || !hidden) {
            return;
        }

        let dragged = null;

        const updateAnswer = () => {
            hidden.value = Array.from(drop.querySelectorAll('.dragChip'))
                .map((chip) => chip.dataset.value || chip.textContent.trim())
                .join(joiner)
                .trim();
        };

        const shufflePool = () => {
            const chips = Array.from(pool.querySelectorAll('.dragChip'));
            chips.sort(() => Math.random() - 0.5).forEach((chip) => pool.appendChild(chip));
        };

        const makeDropZone = (zone) => {
            zone.addEventListener('dragover', (event) => {
                event.preventDefault();
                zone.classList.add('dragZone--active');
            });

            zone.addEventListener('dragleave', () => {
                zone.classList.remove('dragZone--active');
            });

            zone.addEventListener('drop', (event) => {
                event.preventDefault();
                zone.classList.remove('dragZone--active');

                if (dragged) {
                    zone.appendChild(dragged);
                    updateAnswer();
                }
            });
        };

        game.querySelectorAll('.dragChip').forEach((chip) => {
            chip.addEventListener('dragstart', (event) => {
                dragged = chip;
                chip.classList.add('dragChip--dragging');
                event.dataTransfer.effectAllowed = 'move';
            });

            chip.addEventListener('dragend', () => {
                chip.classList.remove('dragChip--dragging');
                dragged = null;
                updateAnswer();
            });

            chip.addEventListener('click', () => {
                if (chip.closest('[data-pool]')) {
                    drop.appendChild(chip);
                } else {
                    pool.appendChild(chip);
                }

                updateAnswer();
            });
        });

        makeDropZone(drop);
        makeDropZone(pool);

        if (reset) {
            reset.addEventListener('click', () => {
                Array.from(drop.querySelectorAll('.dragChip')).forEach((chip) => pool.appendChild(chip));
                shufflePool();
                updateAnswer();
            });
        }

        shufflePool();
        updateAnswer();
    });

    document.querySelectorAll('.flashcard').forEach((card) => {
        card.addEventListener('click', () => {
            card.classList.toggle('flashcard--flipped');
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/lessons/show.blade.php ENDPATH**/ ?>