

<?php $__env->startSection('content'); ?>
<div class="hero">
    <div>
        <h1 class="h1">Мини-игры</h1>
        <p class="muted">Выбирай игру и уровень сложности. Чем сложнее уровень — тем больше награда.</p>
    </div>

    <div class="card">
        <div class="h2">🎮 5</div>
        <div class="muted">видов игр</div>
    </div>
</div>

<div class="gamesGrid gamesGrid--wide">
    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="gameTile gameTile--levels">
            <div class="gameTile__icon"><?php echo e($game['icon']); ?></div>

            <h2><?php echo e($game['title']); ?></h2>
            <p><?php echo e($game['description']); ?></p>

            <div class="levelButtons">
                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="levelBtn levelBtn--<?php echo e($key); ?>" href="<?php echo e(route($game['route'], $key)); ?>">
                        <?php echo e($name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/games/index.blade.php ENDPATH**/ ?>