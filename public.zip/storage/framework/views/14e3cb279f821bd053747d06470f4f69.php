

<?php $__env->startSection('content'); ?>
<div class="travelHero card">
    <div>
        <div class="badge">🌍 Отдельный курс</div>
        <h1 class="h1">Английский для путешествий</h1>
        <p class="muted">
            Изучи самые нужные слова и фразы для аэропорта, отеля, ресторана, такси и экстренных ситуаций.
        </p>
    </div>

    <a class="btn" href="<?php echo e(route('travel.games')); ?>">
        🎮 Игры по путешествиям
    </a>
    <a class="btn" href="<?php echo e(route('travel.scenario')); ?>">
    ✈️ Симулятор путешествия
</a>
</div>

<div class="travelGrid">
    <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card travelLessonCard">
            <div class="badge">
                <?php echo e($lesson->level); ?>

            </div>

            <h2><?php echo e($lesson->title); ?></h2>
            <p class="muted"><?php echo e($lesson->description); ?></p>

            <div class="lessonMeta">
                <span class="pill">🧠 <?php echo e($lesson->exercises_count); ?> заданий</span>

                <?php if(in_array($lesson->id, $completedIds)): ?>
                    <span class="pill">✅ пройден</span>
                <?php else: ?>
                    <span class="pill">⏳ не пройден</span>
                <?php endif; ?>
            </div>

            <a class="btn" href="<?php echo e(route('lessons.show', $lesson)); ?>">
                Начать урок
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/travel/index.blade.php ENDPATH**/ ?>