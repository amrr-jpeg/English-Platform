

<?php $__env->startSection('content'); ?>
<div class="hero">
    <div>
        <h1 class="h1">Сундуки</h1>
        <p class="muted">Открывай ежедневный сундук и получай случайные награды.</p>
    </div>

    <div class="card">
        <div class="h2">🎁</div>
        <div class="muted">1 сундук в день</div>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="toast toast--ok"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="toast toast--bad"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="chestLayout">
    <div class="card chestCard <?php echo e($openedToday ? 'chestCard--opened' : ''); ?>">
        <div class="chestIcon"><?php echo e($openedToday ? '📦' : '🎁'); ?></div>

        <h2 class="h2">
            <?php echo e($openedToday ? 'Сундук уже открыт' : 'Ежедневный сундук'); ?>

        </h2>

        <p class="muted">
            Возможные награды: XP, монеты или смешанная награда.
        </p>

        <form method="POST" action="<?php echo e(route('chests.open')); ?>">
            <?php echo csrf_field(); ?>

            <button class="btn" type="submit" <?php echo e($openedToday ? 'disabled' : ''); ?>>
                <?php echo e($openedToday ? 'Приходи завтра' : 'Открыть сундук'); ?>

            </button>
        </form>
    </div>

    <div class="card">
        <h2 class="h2">История наград</h2>

        <div class="stack">
            <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="rewardHistoryItem">
                    <div><?php echo e($item->reward_label); ?></div>
                    <span class="muted small"><?php echo e($item->created_at->format('d.m.Y H:i')); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Ты ещё не открывал сундуки.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/chests/index.blade.php ENDPATH**/ ?>