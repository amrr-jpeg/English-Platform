

<?php $__env->startSection('content'); ?>
<div class="hero">
    <div>
        <h1 class="h1">Экзамены</h1>
        <p class="muted">Экзамены открываются после прохождения каждых 10 уроков.</p>
    </div>
</div>

<?php if(session('error')): ?>
    <div class="toast toast--bad"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="grid">
    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="badge">
                Уроки <?php echo e($exam['from']); ?>–<?php echo e($exam['to']); ?>

            </div>

            <h2 class="h2"><?php echo e($exam['title']); ?></h2>

            <p class="muted"><?php echo e($exam['description']); ?></p>

            <div class="progress">
                <div class="progress__bar" style="width: <?php echo e($exam['total'] > 0 ? ($exam['completed'] / $exam['total']) * 100 : 0); ?>%"></div>
            </div>

            <p class="muted small">
                Пройдено уроков: <?php echo e($exam['completed']); ?> / <?php echo e($exam['total']); ?>

            </p>

            <?php if($exam['unlocked']): ?>
                <a class="btn" href="<?php echo e(route('exam.start', $exam['number'])); ?>">
    Начать экзамен
</a>
            <?php else: ?>
                <button class="btn btn--disabled" disabled>
                    Заблокировано
                </button>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\english-platform\resources\views/exam/intro.blade.php ENDPATH**/ ?>